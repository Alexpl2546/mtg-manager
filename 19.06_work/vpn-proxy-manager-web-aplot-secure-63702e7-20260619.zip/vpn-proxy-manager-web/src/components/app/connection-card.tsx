"use client";

import { Download, QrCode, Trash2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { ConnectionQr } from "@/components/app/connection-qr";
import { CopyConfigButton } from "@/components/app/copy-config-button";
import { DeviceIcon } from "@/components/app/device-icon";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { Connection } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ConnectionCard({ connection, compact = false }: { connection: Connection; compact?: boolean }) {
  const router = useRouter();
  const [showQr, setShowQr] = useState(false);
  const [revoked, setRevoked] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (revoked) {
    return null;
  }

  async function revoke() {
    setDeleting(true);
    setError(null);
    const response = await fetch(`/api/connections/${connection.id}`, {
      method: "DELETE",
    });
    setDeleting(false);

    if (!response.ok) {
      setError("Не удалось удалить подключение.");
      return;
    }

    setRevoked(true);
    router.refresh();
  }

  return (
    <Card
      className={cn(
        "grid bg-secondary/45",
        compact ? "gap-3 p-3" : "gap-4 p-4 sm:grid-cols-[1fr_auto] sm:items-center",
      )}
    >
      <div className={cn("flex min-w-0 items-center", compact ? "gap-3" : "gap-4")}>
        <DeviceIcon type={connection.deviceType} />
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <Link href={`/connections/${connection.id}`} className={cn("truncate font-semibold hover:text-primary", compact ? "text-base" : "text-lg")}>
              {connection.deviceName}
            </Link>
            <Badge>{connection.protocol}</Badge>
          </div>
        </div>
      </div>
      <div className={cn("grid grid-cols-2 gap-2", compact ? "sm:grid-cols-4" : "sm:flex")}>
        <Button size={compact ? "sm" : "default"} variant="secondary" onClick={() => setShowQr((value) => !value)}>
          <QrCode className="h-4 w-4" />
          QR-код
        </Button>
        <Button asChild size={compact ? "sm" : "default"} variant="secondary">
          <a href={connection.configUrl}>
            <Download className="h-4 w-4" />
            Скачать
          </a>
        </Button>
        <CopyConfigButton configUrl={connection.configUrl} size={compact ? "sm" : "default"} />
        <Button disabled={deleting} size={compact ? "sm" : "default"} variant="destructive" onClick={revoke}>
          <Trash2 className="h-4 w-4" />
          {deleting ? "Удаляем" : "Удалить"}
        </Button>
      </div>
      {error ? <p className="text-sm text-destructive sm:col-span-2">{error}</p> : null}
      {showQr ? (
        <div className="rounded-[var(--radius-panel)] border border-border bg-background/50 p-4 sm:col-span-2">
          <div className="flex flex-col items-center gap-4 sm:flex-row">
            <ConnectionQr value={connection.connectUrl} />
            <div>
              <div className="font-semibold">Сканируйте в приложении VPN</div>
              <p className="mt-1 text-sm text-muted-foreground">
                Внутренние ключи и адреса скрыты. Пользователь получает только готовый QR-код или файл.
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </Card>
  );
}
