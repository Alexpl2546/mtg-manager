"use client";

import { useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type PromoCode = {
  code: string;
  discountPercent: number;
  active: boolean;
};

const plans = [
  { months: 1, discountPercent: 0 },
  { months: 3, discountPercent: 5 },
  { months: 6, discountPercent: 10 },
  { months: 12, discountPercent: 15 },
  { months: 24, discountPercent: 20 },
  { months: 36, discountPercent: 25 },
];

const baseMonthlyPrice = 299;

const rubFormatter = new Intl.NumberFormat("ru-RU", {
  style: "currency",
  currency: "RUB",
  maximumFractionDigits: 0,
});

export function SubscriptionPricing({ promoCodes }: { promoCodes: PromoCode[] }) {
  const [selectedMonths, setSelectedMonths] = useState(6);
  const [promoCodeInput, setPromoCodeInput] = useState("");
  const [appliedPromoCode, setAppliedPromoCode] = useState<PromoCode | null>(null);
  const [promoCodeStatus, setPromoCodeStatus] = useState<"idle" | "applied" | "not-found">("idle");

  const discountTier = getDiscountTier(selectedMonths);
  const basePrice = selectedMonths * baseMonthlyPrice;
  const planPrice = applyDiscount(basePrice, discountTier.discountPercent);
  const totalPrice = appliedPromoCode ? applyDiscount(planPrice, appliedPromoCode.discountPercent) : planPrice;

  const monthlyPrice = useMemo(() => Math.round(totalPrice / selectedMonths), [selectedMonths, totalPrice]);
  const hasPlanDiscount = discountTier.discountPercent > 0;
  const hasPromoDiscount = Boolean(appliedPromoCode);
  const hasAnyDiscount = totalPrice < basePrice;

  function applyPromoCode() {
    const nextPromoCode = getActivePromoCode(promoCodeInput, promoCodes);

    setAppliedPromoCode(nextPromoCode);
    setPromoCodeStatus(nextPromoCode ? "applied" : "not-found");
  }

  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Срок подписки</p>
            <div className="mt-1 text-2xl font-bold">{selectedMonths} мес.</div>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Цена в месяц</p>
            <div className="mt-1 text-lg font-semibold">{rubFormatter.format(monthlyPrice)}</div>
          </div>
        </div>
        <input
          aria-label="Срок подписки"
          className="h-2 w-full cursor-pointer appearance-none rounded-full bg-muted accent-primary"
          max={36}
          min={1}
          onChange={(event) => setSelectedMonths(Number(event.target.value))}
          step={1}
          type="range"
          value={selectedMonths}
        />
      </div>

      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {plans.map((plan) => {
          const isSelected = plan.months === selectedMonths;
          const planBasePrice = plan.months * baseMonthlyPrice;
          const planDiscountPrice = applyDiscount(planBasePrice, plan.discountPercent);

          return (
            <button
              className={cn(
                "rounded-[var(--radius-panel)] border border-border bg-secondary/45 p-4 text-left transition hover:border-cyan-200/45 hover:bg-secondary",
                isSelected && "border-primary/55 bg-primary/15 shadow-[0_0_20px_oklch(0.62_0.19_252_/_0.14)]",
              )}
              key={plan.months}
              onClick={() => setSelectedMonths(plan.months)}
              type="button"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="text-lg font-semibold">{plan.months} мес.</div>
                {plan.discountPercent > 0 ? <div className="text-xs font-semibold text-cyan-100">-{plan.discountPercent}%</div> : null}
              </div>
              <PricePair className="mt-2" originalPrice={planBasePrice} price={planDiscountPrice} showOriginal={plan.discountPercent > 0} />
            </button>
          );
        })}
      </div>

      <div className="space-y-2">
        <div className="grid gap-2 sm:grid-cols-[1fr_auto]">
          <Input
            aria-label="Промокод"
            onChange={(event) => {
              setPromoCodeInput(event.target.value);
              setAppliedPromoCode(null);
              setPromoCodeStatus("idle");
            }}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                applyPromoCode();
              }
            }}
            placeholder="Промокод"
            value={promoCodeInput}
          />
          <Button onClick={applyPromoCode} type="button" variant="secondary">
            Применить
          </Button>
        </div>
        {promoCodeStatus !== "idle" ? (
          <p className={cn("text-sm", promoCodeStatus === "applied" ? "text-cyan-100" : "text-muted-foreground")}>
            {promoCodeStatus === "applied" && appliedPromoCode
              ? `Промокод применен: -${appliedPromoCode.discountPercent}%`
              : "Промокод не найден"}
          </p>
        ) : null}
      </div>

      <div className="brand-panel rounded-[var(--radius-panel)] border border-primary/30 bg-primary/10 p-5">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Итоговая цена</p>
            <PricePair
              className="mt-1"
              originalPrice={hasPromoDiscount ? planPrice : basePrice}
              price={totalPrice}
              showOriginal={hasAnyDiscount}
              size="lg"
            />
            {hasPlanDiscount ? <p className="mt-2 text-sm text-muted-foreground">Скидка за срок: {discountTier.discountPercent}%</p> : null}
          </div>
          <Button>Продлить подписку</Button>
        </div>
      </div>
    </div>
  );
}

function getDiscountTier(months: number) {
  return plans.reduce((selectedPlan, plan) => (months >= plan.months ? plan : selectedPlan), plans[0]);
}

function applyDiscount(price: number, discountPercent: number) {
  return Math.round(price * (1 - discountPercent / 100));
}

function normalizePromoCode(code: string) {
  return code;
}

function getActivePromoCode(code: string, promoCodes: PromoCode[]) {
  const normalizedCode = normalizePromoCode(code);

  if (!normalizedCode) {
    return null;
  }

  return promoCodes.find((promoCode) => promoCode.active && normalizePromoCode(promoCode.code) === normalizedCode) ?? null;
}

function PricePair({
  className,
  originalPrice,
  price,
  showOriginal,
  size = "sm",
}: {
  className?: string;
  originalPrice: number;
  price: number;
  showOriginal: boolean;
  size?: "sm" | "lg";
}) {
  return (
    <div className={cn("flex flex-wrap items-baseline gap-x-3 gap-y-1", className)}>
      {showOriginal ? <DiagonalPrice value={originalPrice} /> : null}
      <span className={cn("font-bold text-cyan-100", size === "lg" ? "text-3xl" : "text-base")}>{rubFormatter.format(price)}</span>
    </div>
  );
}

function DiagonalPrice({ value }: { value: number }) {
  return (
    <span className="relative inline-block text-sm text-muted-foreground">
      <span>{rubFormatter.format(value)}</span>
      <span className="absolute left-0 top-1/2 h-0.5 w-full -rotate-12 bg-destructive" aria-hidden="true" />
    </span>
  );
}
