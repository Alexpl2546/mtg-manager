"use client";

import { Check, Copy } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";

export function CopyConfigButton({
  configUrl,
  size = "default",
  className,
}: {
  configUrl: string;
  size?: "default" | "sm";
  className?: string;
}) {
  const [status, setStatus] = useState<"idle" | "copying" | "copied" | "error">("idle");

  async function copyConfig() {
    setStatus("copying");

    try {
      const response = await fetch(configUrl, { cache: "no-store" });
      if (!response.ok) {
        throw new Error("Config download failed.");
      }

      await navigator.clipboard.writeText(await response.text());
      setStatus("copied");
      window.setTimeout(() => setStatus("idle"), 1800);
    } catch {
      setStatus("error");
    }
  }

  return (
    <Button className={className} disabled={status === "copying"} size={size} variant="secondary" onClick={copyConfig}>
      {status === "copied" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      {status === "copying" ? "Копируем" : status === "copied" ? "Скопировано" : status === "error" ? "Ошибка" : "Скопировать"}
    </Button>
  );
}
