import { Laptop, Monitor, Router, Smartphone } from "lucide-react";

import type { DeviceType } from "@/lib/types";

const iconMap = {
  Телефон: Smartphone,
  Компьютер: Laptop,
  Телевизор: Monitor,
  Роутер: Router,
} satisfies Record<DeviceType, typeof Smartphone>;

export function DeviceIcon({ type }: { type?: DeviceType | string }) {
  const Icon = iconMap[type as DeviceType] ?? Laptop;

  return (
    <div className="flex h-14 w-14 items-center justify-center rounded-[var(--radius-panel)] border border-primary/25 bg-primary/12 text-cyan-100 shadow-[0_0_18px_oklch(0.62_0.19_252_/_0.14)]">
      <Icon className="h-7 w-7" />
    </div>
  );
}
