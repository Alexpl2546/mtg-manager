"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Bell,
  CircleHelp,
  Crown,
  Home,
  LogOut,
  Menu,
  PlugZap,
  Send,
  UserCircle,
  X,
} from "lucide-react";
import { useState } from "react";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { CurrentUser } from "@/lib/types";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Главная", icon: Home },
  { href: "/connections", label: "Подключения", icon: PlugZap },
  { href: "/subscription", label: "Подписка", icon: Crown },
  { href: "/help", label: "Помощь", icon: CircleHelp },
  { href: "/profile", label: "Профиль", icon: UserCircle },
];

export function AppShell({ children, user }: { children: React.ReactNode; user: CurrentUser | null }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const publicRoute = pathname === "/login" || pathname === "/register";

  if (publicRoute) {
    return <main>{children}</main>;
  }

  if (!user) {
    return (
      <main className="grid min-h-screen place-items-center px-4">
        <div className="w-full max-w-sm rounded-[var(--radius-panel)] border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
          <div className="text-lg font-semibold">Требуется вход</div>
          <p className="mt-2 text-sm text-muted-foreground">Войдите в аккаунт, чтобы управлять VPN-доступами.</p>
          <Button asChild className="mt-5 w-full">
            <Link href="/login">Войти</Link>
          </Button>
        </div>
      </main>
    );
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  function toggleNotifications() {
    setNotificationsOpen((value) => !value);
    setProfileOpen(false);
  }

  function toggleProfile() {
    setProfileOpen((value) => !value);
    setNotificationsOpen(false);
  }

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[280px_1fr]">
      <Sidebar pathname={pathname} onNavigate={() => setOpen(false)} className="hidden lg:flex" />
      {open ? (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-xl lg:hidden">
          <Sidebar pathname={pathname} onNavigate={() => setOpen(false)} className="h-full" />
          <Button
            aria-label="Закрыть меню"
            className="absolute right-4 top-4"
            size="icon"
            variant="ghost"
            onClick={() => setOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      ) : null}
      <div className="min-w-0">
        <header className="sticky top-0 z-40 flex h-20 items-center justify-between border-b border-border bg-background/78 px-4 backdrop-blur-xl sm:px-8">
          <Button aria-label="Открыть меню" className="lg:hidden" size="icon" variant="ghost" onClick={() => setOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="ml-auto flex items-center gap-3">
            <div className="relative">
              <Button aria-label="Уведомления" size="icon" variant="ghost" onClick={toggleNotifications}>
                <Bell className="h-5 w-5" />
              </Button>
              {notificationsOpen ? (
                <div className="absolute right-0 top-12 z-50 w-80 rounded-[var(--radius-panel)] border border-border bg-card p-4 shadow-[var(--shadow-soft)]">
                  <div className="font-semibold">Уведомления</div>
                  <div className="mt-3 rounded-[var(--radius-control)] border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
                    Новых уведомлений нет.
                  </div>
                </div>
              ) : null}
            </div>
            <div className="relative">
              <button
                type="button"
                className="flex items-center gap-3 rounded-[var(--radius-control)] border border-border bg-secondary/70 px-3 py-2 transition hover:border-cyan-200/35 hover:bg-accent"
                onClick={toggleProfile}
              >
                <Avatar className="h-9 w-9 bg-[linear-gradient(160deg,var(--brand-cyan),var(--brand-blue))] shadow-[0_0_18px_oklch(0.62_0.19_252_/_0.24)]">
                  <AvatarFallback>{user.avatarFallback}</AvatarFallback>
                </Avatar>
                <span className="hidden text-sm font-semibold sm:inline">{user.name}</span>
              </button>
              {profileOpen ? (
                <div className="absolute right-0 top-14 z-50 w-80 rounded-[var(--radius-panel)] border border-border bg-card p-4 shadow-[var(--shadow-soft)]">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-11 w-11 bg-[linear-gradient(160deg,var(--brand-cyan),var(--brand-blue))] shadow-[0_0_18px_oklch(0.62_0.19_252_/_0.24)]">
                      <AvatarFallback>{user.avatarFallback}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <div className="truncate font-semibold">{user.name}</div>
                      <div className="truncate text-sm text-muted-foreground">{user.email ?? user.phone ?? "Контакт не указан"}</div>
                    </div>
                  </div>
                  <div className="mt-4 space-y-3 border-t border-border pt-4 text-sm">
                    <ProfilePopupRow label="Имя" value={user.name} />
                    <ProfilePopupRow label="Телефон" value={user.phone ?? "не указан"} />
                    <ProfilePopupRow label="Email" value={user.email ?? "не указан"} />
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-muted-foreground">Двухфакторная защита</span>
                      <span className={user.twoFactorEnabled ? "font-semibold text-cyan-100" : "font-semibold text-destructive"}>
                        {user.twoFactorEnabled ? "включена" : "отключена"}
                      </span>
                    </div>
                  </div>
                  <div className="mt-4 grid gap-2">
                    <Button className="w-full justify-start" variant="ghost" onClick={logout}>
                      <LogOut className="h-4 w-4" />
                      Выйти
                    </Button>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </header>
        <main className="w-full px-4 py-8 sm:px-8 lg:max-w-[calc(100vw-280px)]">{children}</main>
      </div>
    </div>
  );
}

function ProfilePopupRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-muted-foreground">{label}</span>
      <span className="min-w-0 truncate font-semibold">{value}</span>
    </div>
  );
}

function Sidebar({
  pathname,
  onNavigate,
  className,
}: {
  pathname: string;
  onNavigate: () => void;
  className?: string;
}) {
  return (
    <aside className={cn("flex flex-col border-r border-border bg-secondary/50 p-6 backdrop-blur-xl", className)}>
      <Link href="/" className="mb-10 flex items-center gap-3" onClick={onNavigate}>
        <span className="brand-mark" aria-hidden="true" />
        <span className="text-xl font-bold tracking-tight">APlot Secure</span>
      </Link>
      <nav className="space-y-2">
        {navItems.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 rounded-[var(--radius-control)] px-4 py-3 text-sm font-semibold text-muted-foreground transition",
                active &&
                  "border border-primary/35 bg-primary/18 text-cyan-100 shadow-[0_0_24px_oklch(0.62_0.19_252_/_0.18)]",
                !active && "hover:bg-accent hover:text-foreground",
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto space-y-5">
        <Card className="brand-panel bg-secondary/60 p-5">
          <div className="mb-4 inline-flex rounded-[var(--radius-control)] border border-primary/25 bg-primary/12 p-3 text-cyan-100 shadow-[0_0_18px_oklch(0.78_0.14_220_/_0.2)]">
            <Send className="h-6 w-6" />
          </div>
          <div className="font-semibold">Поддержка</div>
          <p className="mt-2 text-sm text-muted-foreground">Откройте чат, если нужна помощь с доступом.</p>
          <Button asChild className="mt-5 w-full">
            <a href={process.env.NEXT_PUBLIC_TELEGRAM_BOT_URL ?? "https://t.me/"} target="_blank" rel="noreferrer">
              Открыть бота
            </a>
          </Button>
        </Card>
      </div>
    </aside>
  );
}
