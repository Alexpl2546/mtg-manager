"use client";

import Image from "next/image";
import QRCode from "qrcode";
import { useEffect, useState } from "react";

import { cn } from "@/lib/utils";

export function ConnectionQr({ value, className }: { value: string; className?: string }) {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    QRCode.toDataURL(value, {
      errorCorrectionLevel: "M",
      margin: 2,
      scale: 8,
      color: {
        dark: "#04111f",
        light: "#eefbff",
      },
    })
      .then((dataUrl) => {
        if (active) {
          setSrc(dataUrl);
        }
      })
      .catch(() => {
        if (active) {
          setSrc(null);
        }
      });

    return () => {
      active = false;
    };
  }, [value]);

  return (
    <div
      className={cn(
        "grid h-44 w-44 place-items-center rounded-[var(--radius-panel)] border border-cyan-200/25 bg-cyan-50 p-3 shadow-[0_0_28px_oklch(0.78_0.14_220_/_0.18)]",
        className,
      )}
      aria-label="QR-код подключения"
    >
      {src ? (
        <Image alt="QR-код подключения" className="h-full w-full" height={176} src={src} unoptimized width={176} />
      ) : (
        <div className="h-full w-full rounded-[var(--radius-control)] bg-cyan-100" />
      )}
    </div>
  );
}
