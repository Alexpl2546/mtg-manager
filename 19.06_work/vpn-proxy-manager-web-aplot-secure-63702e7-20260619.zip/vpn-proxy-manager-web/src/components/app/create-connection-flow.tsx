"use client";

import { Check, Download, Plus, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { ConnectionQr } from "@/components/app/connection-qr";
import { CopyConfigButton } from "@/components/app/copy-config-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import type { Connection, DeviceType, ProtocolChoice } from "@/lib/types";
import { cn } from "@/lib/utils";

const devices: DeviceType[] = ["Телефон", "Компьютер", "Телевизор", "Роутер"];
const defaultDeviceNames: Record<DeviceType, string> = {
  Телефон: "Phone",
  Компьютер: "Computer",
  Телевизор: "TV",
  Роутер: "Router",
};
const protocols: Array<{ value: ProtocolChoice; description: string }> = [
  {
    value: "VLESS Reality",
    description: "Основной вариант: маскирует VPN-трафик под обычное TLS-соединение и хорошо работает в сложных сетях.",
  },
  {
    value: "AmneziaWG",
    description: "WireGuard-подключение с дополнительной обфускацией. Будет доступно позднее.",
  },
];

export function CreateConnectionFlow({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [deviceType, setDeviceType] = useState<DeviceType>("Телефон");
  const [deviceName, setDeviceName] = useState("Phone");
  const [protocol, setProtocol] = useState<ProtocolChoice>("VLESS Reality");
  const [result, setResult] = useState<Connection | null>(null);
  const [error, setError] = useState<string | null>(null);

  function resetFlow() {
    setStep(1);
    setDeviceType("Телефон");
    setDeviceName(defaultDeviceNames["Телефон"]);
    setProtocol("VLESS Reality");
    setResult(null);
    setError(null);
  }

  function openFlow() {
    resetFlow();
    setOpen(true);
  }

  function nextStep() {
    setError(null);
    if (step === 1) {
      setDeviceName(defaultDeviceNames[deviceType]);
    }
    setStep((value) => value + 1);
  }

  async function finish() {
    setError(null);
    if (protocol === "AmneziaWG") {
      setError("AmneziaWG будет доступно позднее.");
      return;
    }

    const response = await fetch("/api/connections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceType, deviceName, protocol }),
    });

    if (!response.ok) {
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      setError(
        payload?.error === "quota_exceeded"
          ? "Лимит подключений исчерпан."
          : payload?.error === "amneziawg_coming_later"
            ? "AmneziaWG будет доступно позднее."
            : "Не удалось создать подключение.",
      );
      return;
    }

    const created = (await response.json()) as Connection;
    setResult(created);
    setStep(4);
    router.refresh();
  }

  return (
    <>
      <Button className={compact ? "w-full" : ""} onClick={openFlow}>
        <Plus className="h-5 w-5" />
        Создать подключение
      </Button>
      {open ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/85 p-4 backdrop-blur-xl">
          <Card className="max-h-[92vh] w-full max-w-2xl overflow-auto p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <Badge>Шаг {step} из 4</Badge>
                <h2 className="mt-3 text-2xl font-bold">Новое подключение</h2>
              </div>
              <Button variant="ghost" onClick={() => setOpen(false)}>
                Закрыть
              </Button>
            </div>
            <Separator className="my-6" />
            {step === 1 ? (
              <div className="space-y-4">
                <Label>Выберите устройство</Label>
                <div className="grid gap-3 sm:grid-cols-2">
                  {devices.map((item) => (
                    <button
                      key={item}
                      className={cn(
                        "rounded-[var(--radius-panel)] border border-border bg-secondary/50 p-5 text-left transition hover:border-cyan-200/45",
                        deviceType === item && "border-primary/55 bg-primary/15 shadow-[0_0_20px_oklch(0.62_0.19_252_/_0.14)]",
                      )}
                      onClick={() => setDeviceType(item)}
                    >
                      <div className="font-semibold">{item}</div>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
            {step === 2 ? (
              <div className="space-y-3">
                <Label htmlFor="device-name">Название устройства</Label>
                <Input id="device-name" value={deviceName} onChange={(event) => setDeviceName(event.target.value)} />
                <p className="text-sm text-muted-foreground">Например: Phone, Laptop, TV, Router.</p>
              </div>
            ) : null}
            {step === 3 ? (
              <div className="space-y-4">
                <Label>Протокол</Label>
                <div className="grid gap-3">
                  {protocols.map((item) => (
                    <button
                      key={item.value}
                      className={cn(
                        "flex items-center justify-between rounded-[var(--radius-panel)] border border-border bg-secondary/50 p-4 text-left transition hover:border-cyan-200/45",
                        protocol === item.value && "border-primary/55 bg-primary/15 shadow-[0_0_20px_oklch(0.62_0.19_252_/_0.14)]",
                      )}
                      onClick={() => {
                        setProtocol(item.value);
                        setError(item.value === "AmneziaWG" ? "AmneziaWG будет доступно позднее." : null);
                      }}
                    >
                      <span>
                        <span className="block font-semibold">{item.value}</span>
                        <span className="text-sm text-muted-foreground">{item.description}</span>
                      </span>
                      {protocol === item.value ? <Check className="h-5 w-5 text-primary" /> : null}
                    </button>
                  ))}
                </div>
                {error ? <p className="text-sm text-destructive">{error}</p> : null}
              </div>
            ) : null}
            {step === 4 && result ? (
              <div className="grid gap-6 sm:grid-cols-[auto_1fr]">
                <ConnectionQr value={result.connectUrl} className="mx-auto" />
                <div>
                  <Badge variant="success">
                    <Sparkles className="mr-1 h-3 w-3" />
                    Готово
                  </Badge>
                  <h3 className="mt-3 text-xl font-semibold">{result.deviceName}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">Отсканируйте QR-код или скачайте файл.</p>
                  <div className="mt-5 grid gap-2 sm:grid-cols-2">
                    <Button asChild variant="secondary">
                      <a href={result.configUrl}>
                        <Download className="h-4 w-4" />
                        Скачать
                      </a>
                    </Button>
                    <CopyConfigButton configUrl={result.configUrl} />
                  </div>
                  <Card className="mt-5 bg-secondary/45 p-4 text-sm text-muted-foreground">
                    Инструкция: установите приложение, импортируйте конфигурацию через QR-код или файл, затем нажмите
                    «Подключиться».
                  </Card>
                </div>
              </div>
            ) : null}
            <div className="mt-8 flex justify-between">
              <Button disabled={step === 1} variant="ghost" onClick={() => setStep((value) => Math.max(1, value - 1))}>
                Назад
              </Button>
              {step < 3 ? <Button onClick={nextStep}>Далее</Button> : null}
              {step === 3 ? <Button disabled={!deviceName.trim()} onClick={finish}>Создать</Button> : null}
              {step === 4 ? <Button onClick={() => setOpen(false)}>Готово</Button> : null}
            </div>
          </Card>
        </div>
      ) : null}
    </>
  );
}
