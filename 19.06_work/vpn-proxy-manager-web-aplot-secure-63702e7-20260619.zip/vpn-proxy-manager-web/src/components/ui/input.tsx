import * as React from "react";

import { cn } from "@/lib/utils";

export function Input({ className, type, ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      type={type}
      className={cn(
        "flex h-11 w-full rounded-[var(--radius-control)] border border-border bg-input px-4 py-2 text-sm text-foreground outline-none transition-all duration-200 placeholder:text-muted-foreground focus:border-cyan-200/55 focus:ring-2 focus:ring-ring/20",
        className,
      )}
      {...props}
    />
  );
}
