import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium", {
  variants: {
    variant: {
      default: "border-primary/30 bg-primary/12 text-cyan-100 shadow-[0_0_18px_oklch(0.62_0.19_252_/_0.12)]",
      success: "border-success/35 bg-success/12 text-cyan-100",
      danger: "border-destructive/35 bg-destructive/10 text-red-200",
      muted: "border-border bg-muted text-muted-foreground",
      warning: "border-warning/35 bg-warning/12 text-cyan-100",
    },
  },
  defaultVariants: {
    variant: "default",
  },
});

export type BadgeProps = React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof badgeVariants>;

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant, className }))} {...props} />;
}
