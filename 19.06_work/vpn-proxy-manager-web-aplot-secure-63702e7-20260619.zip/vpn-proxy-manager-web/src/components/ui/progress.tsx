import * as React from "react";

import { cn } from "@/lib/utils";

export function Progress({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-2 overflow-hidden rounded-full border border-border/60 bg-muted", className)}>
      <div
        className="h-full rounded-full bg-[linear-gradient(90deg,var(--brand-blue-strong),var(--brand-blue),var(--brand-cyan))] shadow-[0_0_18px_oklch(0.78_0.14_220_/_0.38)]"
        style={{ width: `${Math.max(0, Math.min(value, 100))}%` }}
      />
    </div>
  );
}
