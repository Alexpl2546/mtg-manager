import type { CreateConnectionInput, Protocol } from "@/lib/types";
import { createXuiMutationClient, unwrapInbound } from "@/lib/server/xui-client";
import { getXuiExpectedConfig, matchTargetInbound } from "@/lib/server/xui-diagnostics";

export type XuiClientInput = {
  ownerId: string;
  ownerEmail?: string;
  deviceName: string;
  deviceType: CreateConnectionInput["deviceType"];
  protocol: CreateConnectionInput["protocol"];
};

export type XuiClient = {
  externalId: string;
  protocol: Protocol;
  connectUrl: string;
  configText: string;
  subscriptionUrl?: string;
};

export type XuiClientSyncState =
  | { state: "present" }
  | { state: "missing" }
  | { state: "unknown"; reason: "disabled" | "request_failed" | "unexpected_response" };

export type XuiGroupEnsureResult =
  | { ok: true; groupName: string; skipped?: boolean }
  | { ok: false; groupName: string; error: string };

function realMutationsEnabled() {
  return process.env.XUI_ENABLE_REAL_CLIENT_MUTATIONS === "true";
}

function getRealClientConfig() {
  const panelBaseUrl = process.env.XUI_PANEL_BASE_URL?.trim();
  const apiToken = process.env.XUI_API_TOKEN?.trim();
  const sessionCookie = process.env.XUI_SESSION_COOKIE?.trim();

  if (!panelBaseUrl || (!apiToken && !sessionCookie)) {
    return null;
  }

  return {
    panelBaseUrl,
    apiToken,
    sessionCookie,
  };
}

function selectProtocol(input: XuiClientInput): Protocol {
  return input.protocol;
}

function buildBaseClientEmail(input: XuiClientInput) {
  const safeDevice = sanitizeClientNamePart(input.deviceName, "device").slice(0, 32);
  const safeOwner = sanitizeClientNamePart(input.ownerEmail || input.ownerId, "user").slice(0, 48);
  return `${safeDevice}-${safeOwner}`;
}

function buildRemark(input: XuiClientInput) {
  return `${input.deviceName.trim() || "Device"} ${input.ownerEmail || input.ownerId}`.slice(0, 64);
}

function buildGroupName(input: XuiClientInput) {
  return input.ownerEmail?.trim().toLowerCase() || input.ownerId;
}

function getUserGroupName(ownerId: string, ownerEmail?: string) {
  return ownerEmail?.trim().toLowerCase() || ownerId;
}

function sanitizeClientNamePart(value: string | undefined, fallback: string) {
  return (value?.trim().toLowerCase() || fallback)
    .replace(/[^\p{L}\p{N}._@-]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-{2,}/g, "-") || fallback;
}

export async function createXuiClientMock(input: XuiClientInput): Promise<XuiClient> {
  const externalId = `mock-xui-${buildBaseClientEmail(input)}`;
  const protocol = selectProtocol(input);
  const safeName = input.deviceName.trim().replace(/\s+/g, "-").toLowerCase();
  const connectUrl =
    protocol === "VLESS Reality"
      ? `vless://${externalId}@homepanel-v3.local:24443?security=reality&type=tcp#${encodeURIComponent(safeName)}`
      : `amneziawg://mock/${externalId}#${encodeURIComponent(safeName)}`;

  return {
    externalId,
    protocol,
    connectUrl,
    subscriptionUrl: "https://sub-v3.route98.netcraze.pro/",
    configText: [
      `# Mock ${protocol} configuration`,
      "# 3x-ui v3 integration is intentionally disabled until read-only diagnostics are complete.",
      `# owner_id=${input.ownerId}`,
      `# external_id=${externalId}`,
      connectUrl,
      "",
    ].join("\n"),
  };
}

export async function createXuiClient(input: XuiClientInput): Promise<XuiClient> {
  const protocol = selectProtocol(input);
  const config = getRealClientConfig();

  if (!realMutationsEnabled() || !config || protocol !== "VLESS Reality") {
    return createXuiClientMock(input);
  }

  const expected = getXuiExpectedConfig();
  const client = createXuiMutationClient(config);
  const inbounds = await client.listInbounds();
  const target = matchTargetInbound(inbounds.inbounds, expected.inboundRemark, expected.inboundPort);

  if (!inbounds.ok || !target?.inbound.id) {
    throw new Error("Target 3x-ui inbound is not available for client creation.");
  }

  const inboundDetail = await client.getInbound(target.inbound.id);
  const inbound = inboundDetail.data ? unwrapInbound(inboundDetail.data) : undefined;
  if (!inboundDetail.ok || inbound?.tag !== expected.routingInboundTag) {
    throw new Error("Target 3x-ui inbound detail did not match expected routing tag.");
  }

  const email = await resolveAvailableClientEmail(client, buildBaseClientEmail(input));
  const group = buildGroupName(input);
  await ensureXuiGroup(client, group).catch(() => undefined);

  const result = await client.createClient({
    inboundId: target.inbound.id,
    email,
    remark: buildRemark(input),
  });

  if (!result.ok || result.data?.success === false) {
    throw new Error(result.data?.msg || "3x-ui client creation failed.");
  }

  const groupResult = await client.addClientsToGroup([email], group);
  if (!groupResult.ok || groupResult.data?.success === false) {
    await client.deleteClient(email);
    throw new Error(groupResult.data?.msg || "3x-ui client group assignment failed.");
  }

  const links = await client.getClientLinks(email);
  const connectUrl = links.data?.obj?.[0];
  if (!links.ok || !connectUrl) {
    throw new Error("3x-ui client was created, but no connection link was returned.");
  }

  return {
    externalId: email,
    protocol,
    connectUrl,
    configText: [`# VLESS Reality configuration`, `# owner_id=${input.ownerId}`, `# external_id=${email}`, connectUrl, ""].join("\n"),
  };
}

export async function revokeXuiClientMock(externalId: string) {
  void externalId;
  return { ok: true };
}

export async function revokeXuiClient(externalId: string) {
  const config = getRealClientConfig();
  if (!realMutationsEnabled() || !config || externalId.startsWith("mock-xui-")) {
    return revokeXuiClientMock(externalId);
  }

  const client = createXuiMutationClient(config);
  const result = await client.deleteClient(externalId);
  if (!result.ok || result.data?.success === false) {
    return { ok: false };
  }

  return { ok: true };
}

export async function ensureXuiUserGroup(ownerId: string, ownerEmail?: string): Promise<XuiGroupEnsureResult> {
  const groupName = getUserGroupName(ownerId, ownerEmail);
  const config = getRealClientConfig();
  if (!realMutationsEnabled() || !config) {
    return { ok: true, groupName, skipped: true };
  }

  try {
    await ensureXuiGroup(createXuiMutationClient(config), groupName);
    return { ok: true, groupName };
  } catch (error) {
    return { ok: false, groupName, error: error instanceof Error ? error.message : "3x-ui group creation failed." };
  }
}

export async function getXuiClientSyncState(externalId: string): Promise<XuiClientSyncState> {
  const config = getRealClientConfig();
  if (!realMutationsEnabled() || !config || externalId.startsWith("mock-xui-")) {
    return { state: "present" };
  }

  try {
    const result = await createXuiMutationClient(config).getClient(externalId);
    if (result.status === 404 || result.data?.success === false) {
      return { state: "missing" };
    }

    if (!result.ok) {
      return { state: "unknown", reason: "request_failed" };
    }

    if (result.data?.obj) {
      return { state: "present" };
    }

    if (result.data && result.data.obj === null) {
      return { state: "missing" };
    }

    return { state: "unknown", reason: "unexpected_response" };
  } catch {
    return { state: "unknown", reason: "request_failed" };
  }
}

async function resolveAvailableClientEmail(client: ReturnType<typeof createXuiMutationClient>, baseEmail: string) {
  for (let index = 1; index <= 50; index += 1) {
    const candidate = index === 1 ? baseEmail : `${baseEmail}-${index}`;
    const existing = await client.getClient(candidate);
    if (!existing.ok || existing.status === 404 || existing.data?.success === false || !existing.data?.obj) {
      return candidate;
    }
  }

  throw new Error("Could not find an available 3x-ui client name.");
}

async function ensureXuiGroup(client: ReturnType<typeof createXuiMutationClient>, groupName: string) {
  const groups = await client.listGroups();
  if (groups.ok && groups.data?.success !== false && Array.isArray(groups.data?.obj)) {
    const exists = groups.data.obj.some((group) => group.name?.trim().toLowerCase() === groupName.toLowerCase());
    if (exists) {
      return;
    }
  }

  const result = await client.createGroup(groupName);
  if (result.ok && result.data?.success !== false) {
    return;
  }

  const message = result.data?.msg || "3x-ui group creation failed.";
  if (/exist|already|duplicate|существ/i.test(message)) {
    return;
  }

  throw new Error(message);
}
