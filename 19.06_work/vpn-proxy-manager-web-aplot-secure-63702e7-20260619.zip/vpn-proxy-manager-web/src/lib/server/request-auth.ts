import type { CurrentUser } from "@/lib/types";
import { getUserById, getUserBySessionToken } from "@/lib/server/vpn-store";

function toCurrentUser(user: NonNullable<Awaited<ReturnType<typeof getUserById>>>): CurrentUser {
  return {
    id: user.id,
    name: user.name,
    telegram: user.telegram,
    email: user.email,
    avatarFallback: user.avatarFallback,
    role: user.role,
    status: user.status,
    quotaConfigs: user.quotaConfigs,
    usedConfigs: user.usedConfigs,
  };
}

export async function getRequestUser(request?: Request): Promise<CurrentUser | null> {
  const authHeader = request?.headers.get("authorization");
  const token = authHeader?.match(/^Bearer\s+(.+)$/i)?.[1];
  const cookieHeader = request?.headers.get("cookie");
  const sessionToken = cookieHeader
    ?.split(";")
    .map((item) => item.trim())
    .find((item) => item.startsWith("vpn_session="))
    ?.split("=")[1];

  const sessionUser = await getUserBySessionToken(sessionToken ? decodeURIComponent(sessionToken) : null);
  if (sessionUser) {
    return sessionUser;
  }

  if (process.env.NODE_ENV !== "production" && token?.startsWith("demo:")) {
    const user = await getUserById(token.slice("demo:".length));
    if (user) {
      return toCurrentUser(user);
    }
  }

  if (process.env.NODE_ENV !== "production") {
    const demoUserId = request?.headers.get("x-demo-user-id");
    if (demoUserId) {
      const user = await getUserById(demoUserId);
      if (user) {
        return toCurrentUser(user);
      }
    }
  }

  return null;
}

export async function requireAdmin(request: Request) {
  const adminToken = process.env.VPN_ADMIN_API_TOKEN;
  const authHeader = request.headers.get("authorization");
  const token = authHeader?.match(/^Bearer\s+(.+)$/i)?.[1];

  if (adminToken && token === adminToken) {
    const admin = await getUserById("admin_01");
    return { ok: true as const, actorId: admin?.id ?? "admin" };
  }

  const user = await getRequestUser(request);
  if (user?.role === "admin" && user.status === "active") {
    return { ok: true as const, actorId: user.id };
  }

  return { ok: false as const, status: 403, error: "Admin role required" };
}
