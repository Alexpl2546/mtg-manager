import { randomUUID, scryptSync, timingSafeEqual } from "crypto";
import { mkdir, readFile, rename, writeFile } from "fs/promises";
import path from "path";

import type {
  Connection,
  CreateConnectionInput,
  CurrentUser,
  DeviceType,
  Protocol,
  Server,
  Subscription,
} from "@/lib/types";
import { createXuiClient, ensureXuiUserGroup, getXuiClientSyncState, revokeXuiClient } from "@/lib/server/three-x-ui";

export type UserRole = "admin" | "user";
export type UserStatus = "active" | "blocked";

export type ManagedUser = {
  id: string;
  role: UserRole;
  status: UserStatus;
  name: string;
  telegram?: string;
  phone?: string;
  telegramId?: string;
  email?: string;
  avatarFallback: string;
  passwordHash: string;
  quotaConfigs: number;
  usedConfigs: number;
  twoFactorEnabled: boolean;
  twoFactorMethod?: "totp" | "email" | "sms";
  createdAt: string;
  updatedAt: string;
};

export type ManagedConfig = {
  id: string;
  ownerId: string;
  externalClientId: string;
  xuiGroupName?: string;
  deviceName: string;
  deviceType: DeviceType;
  protocol: Protocol;
  status: "active" | "revoked";
  createdAt: string;
  revokedAt?: string;
  lastUsedAt?: string;
  connectUrl: string;
  configText: string;
};

export type AuditEvent = {
  id: string;
  actorId: string;
  action: string;
  targetType: "user" | "config" | "system";
  targetId: string;
  createdAt: string;
  details?: Record<string, string | number | boolean | null>;
};

export type PromoCode = {
  code: string;
  discountPercent: number;
  active: boolean;
  createdAt: string;
};

type VpnDb = {
  version: 1;
  users: ManagedUser[];
  configs: ManagedConfig[];
  audit: AuditEvent[];
  sessions: ManagedSession[];
  promoCodes: PromoCode[];
};

type ManagedSession = {
  tokenHash: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
  twoFactorVerified: boolean;
};

const dataDir = process.env.VPN_MANAGER_DATA_DIR ?? path.join(process.cwd(), ".local-data");
const dbPath = path.join(dataDir, "vpn-manager.json");

let writeQueue = Promise.resolve();

function now() {
  return new Date().toISOString();
}

function hashPassword(password: string, salt = "netconnect-dev-salt") {
  return `scrypt:${salt}:${scryptSync(password, salt, 32).toString("hex")}`;
}

function hashSessionToken(token: string) {
  return scryptSync(token, "netconnect-session-salt", 32).toString("hex");
}

function verifyPassword(password: string, storedHash: string) {
  const [, salt, hash] = storedHash.split(":");
  if (!salt || !hash) {
    return false;
  }

  const expected = Buffer.from(hash, "hex");
  const actual = scryptSync(password, salt, expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function makeAudit(
  actorId: string,
  action: string,
  targetType: AuditEvent["targetType"],
  targetId: string,
  details?: AuditEvent["details"],
): AuditEvent {
  return {
    id: randomUUID(),
    actorId,
    action,
    targetType,
    targetId,
    createdAt: now(),
    details,
  };
}

function seedDb(): VpnDb {
  const createdAt = now();
  const users: ManagedUser[] = [
    {
      id: "admin_01",
      role: "admin",
      status: "active",
      name: "Administrator",
      telegram: "@admin",
      email: "admin@netconnect.local",
      avatarFallback: "AD",
      passwordHash: hashPassword("admin-demo"),
      quotaConfigs: 0,
      usedConfigs: 0,
      twoFactorEnabled: false,
      createdAt,
      updatedAt: createdAt,
    },
  ];

  return {
    version: 1,
    users,
    configs: [],
    audit: [makeAudit("system", "db.seeded", "system", "vpn-manager")],
    sessions: [],
    promoCodes: [
      {
        code: "НОВОЕНАЧАЛО",
        discountPercent: 50,
        active: true,
        createdAt,
      },
    ],
  };
}

function defaultPromoCodes(): PromoCode[] {
  return [
    {
      code: "НОВОЕНАЧАЛО",
      discountPercent: 50,
      active: true,
      createdAt: now(),
    },
  ];
}

async function writeDb(db: VpnDb) {
  await mkdir(dataDir, { recursive: true });
  const tempPath = `${dbPath}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(tempPath, `${JSON.stringify(db, null, 2)}\n`, "utf8");
  await rename(tempPath, dbPath);
}

async function readDb(): Promise<VpnDb> {
  try {
    const raw = await readFile(dbPath, "utf8");
    const db = JSON.parse(raw) as VpnDb;
    db.sessions ??= [];
    db.promoCodes ??= defaultPromoCodes();
    for (const user of db.users) {
      user.twoFactorEnabled ??= false;
      user.avatarFallback ||= user.name.slice(0, 2).toUpperCase();
    }
    return db;
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code !== "ENOENT") {
      throw error;
    }

    const db = seedDb();
    await writeDb(db);
    return db;
  }
}

async function updateDb<T>(mutator: (db: VpnDb) => Promise<T> | T): Promise<T> {
  const next = writeQueue.then(async () => {
    const db = await readDb();
    const result = await mutator(db);
    await writeDb(db);
    return result;
  });
  writeQueue = next.then(
    () => undefined,
    () => undefined,
  );
  return next;
}

function toCurrentUser(user: ManagedUser): CurrentUser {
  return {
    id: user.id,
    name: user.name,
    telegram: user.telegram,
    phone: user.phone,
    email: user.email,
    avatarFallback: user.avatarFallback,
    role: user.role,
    status: user.status,
    quotaConfigs: user.quotaConfigs,
    usedConfigs: user.usedConfigs,
    twoFactorEnabled: user.twoFactorEnabled,
  };
}

function toConnection(config: ManagedConfig): Connection {
  const createdAt = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(
    new Date(config.createdAt),
  );

  return {
    id: config.id,
    ownerId: config.ownerId,
    deviceName: config.deviceName,
    deviceType: config.deviceType,
    protocol: config.protocol,
    status: config.status === "active" ? "Подключено" : "Отключено",
    createdAt,
    lastUsedAt: config.lastUsedAt ?? "ещё не использовалось",
    configUrl: `/api/connections/${config.id}/config`,
    connectUrl: config.connectUrl,
  };
}

export async function getUserById(id: string) {
  const db = await readDb();
  return db.users.find((user) => user.id === id) ?? null;
}

export async function getDefaultUser() {
  return (await readDb()).users.find((user) => user.role === "user") ?? null;
}

export async function getCurrentUserFromStore() {
  return null;
}

function normalizeIdentifier(value: string) {
  return value.trim().toLowerCase();
}

function normalizePhone(value?: string) {
  return value?.replace(/[^\d+]/g, "").trim();
}

function getUserXuiGroupName(user: Pick<ManagedUser, "id" | "email">) {
  return user.email?.trim().toLowerCase() || user.id;
}

function countActiveConfigs(db: VpnDb, ownerId: string) {
  return db.configs.filter((config) => config.ownerId === ownerId && config.status === "active").length;
}

async function ensureAndAuditXuiUserGroup(actorId: string, user: Pick<ManagedUser, "id" | "email">) {
  const result = await ensureXuiUserGroup(user.id, user.email);
  await updateDb((db) => {
    db.audit.push(
      makeAudit(
        actorId,
        result.ok ? "xui.group.ensure.succeeded" : "xui.group.ensure.failed",
        "user",
        user.id,
        {
          groupName: result.groupName,
          skipped: result.ok ? Boolean(result.skipped) : false,
          error: result.ok ? null : result.error,
        },
      ),
    );
  });
}

function makeSessionToken() {
  return randomUUID() + randomUUID().replace(/-/g, "");
}

export async function createSessionForUser(userId: string) {
  return updateDb((db) => {
    const token = makeSessionToken();
    const createdAt = now();
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString();
    db.sessions = db.sessions.filter((session) => session.userId !== userId || new Date(session.expiresAt) > new Date());
    db.sessions.push({
      tokenHash: hashSessionToken(token),
      userId,
      createdAt,
      expiresAt,
      twoFactorVerified: true,
    });
    db.audit.push(makeAudit(userId, "auth.session.created", "user", userId));
    return { token, expiresAt };
  });
}

export async function getUserBySessionToken(token?: string | null) {
  if (!token) {
    return null;
  }

  const db = await readDb();
  const tokenHash = hashSessionToken(token);
  const session = db.sessions.find((item) => item.tokenHash === tokenHash && new Date(item.expiresAt) > new Date());
  if (!session) {
    return null;
  }

  const user = db.users.find((item) => item.id === session.userId && item.status === "active");
  return user ? toCurrentUser(user) : null;
}

export async function revokeSessionToken(token?: string | null) {
  if (!token) {
    return { ok: true };
  }

  return updateDb((db) => {
    const tokenHash = hashSessionToken(token);
    db.sessions = db.sessions.filter((session) => session.tokenHash !== tokenHash);
    return { ok: true };
  });
}

export async function loginUser(identifier: string, password: string) {
  const db = await readDb();
  const normalized = normalizeIdentifier(identifier);
  const phone = normalizePhone(identifier);
  const user = db.users.find(
    (item) =>
      item.email?.toLowerCase() === normalized ||
      item.phone === phone ||
      item.telegram?.toLowerCase() === normalized ||
      item.telegramId === identifier.trim(),
  );

  if (!user || user.status !== "active" || !verifyPassword(password, user.passwordHash)) {
    return null;
  }

  const session = await createSessionForUser(user.id);
  return {
    token: session.token,
    tokenType: "Bearer",
    expiresAt: session.expiresAt,
    twoFactorRequired: user.twoFactorEnabled,
    user: toCurrentUser(user),
  };
}

export async function registerUser(input: {
  name: string;
  email: string;
  phone?: string;
  password: string;
}) {
  const result = await updateDb((db) => {
    const email = input.email.trim().toLowerCase();
    const phone = normalizePhone(input.phone);
    if (!email || !email.includes("@")) {
      return { error: "invalid_email" as const };
    }
    if (input.password.length < 8) {
      return { error: "weak_password" as const };
    }
    if (db.users.some((user) => user.email?.toLowerCase() === email)) {
      return { error: "email_exists" as const };
    }
    if (phone && db.users.some((user) => user.phone === phone)) {
      return { error: "phone_exists" as const };
    }

    const createdAt = now();
    const user: ManagedUser = {
      id: `user_${randomUUID()}`,
      role: "user",
      status: "active",
      name: input.name.trim() || email.split("@")[0],
      email,
      phone,
      avatarFallback: (input.name.trim() || email).slice(0, 2).toUpperCase(),
      passwordHash: hashPassword(input.password),
      quotaConfigs: 0,
      usedConfigs: 0,
      twoFactorEnabled: false,
      createdAt,
      updatedAt: createdAt,
    };
    db.users.push(user);
    db.audit.push(makeAudit(user.id, "user.registered", "user", user.id, { emailConfigured: true, phoneConfigured: Boolean(phone) }));
    const token = makeSessionToken();
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString();
    db.sessions.push({
      tokenHash: hashSessionToken(token),
      userId: user.id,
      createdAt,
      expiresAt,
      twoFactorVerified: true,
    });
    return { user: toCurrentUser(user), token, tokenType: "Bearer" as const, expiresAt };
  });

  if ("user" in result && result.user) {
    await ensureAndAuditXuiUserGroup(result.user.id, result.user);
  }

  return result;
}

export async function listUsers() {
  const db = await readDb();
  return db.users.map(toCurrentUser);
}

export async function createUser(actorId: string, input: { name: string; telegram: string; telegramId?: string; email?: string; role?: UserRole; status?: UserStatus; quotaConfigs?: number }) {
  const user = await updateDb((db) => {
    const createdAt = now();
    const user: ManagedUser = {
      id: `user_${randomUUID()}`,
      role: input.role === "admin" ? "admin" : "user",
      status: input.status === "blocked" ? "blocked" : "active",
      name: input.name,
      telegram: input.telegram,
      telegramId: input.telegramId,
      email: input.email,
      avatarFallback: input.name.slice(0, 2).toUpperCase(),
      passwordHash: hashPassword("demo-password"),
      quotaConfigs: Number.isFinite(input.quotaConfigs) ? Number(input.quotaConfigs) : 0,
      usedConfigs: 0,
      twoFactorEnabled: false,
      createdAt,
      updatedAt: createdAt,
    };
    db.users.push(user);
    db.audit.push(makeAudit(actorId, "user.created", "user", user.id, { quotaConfigs: user.quotaConfigs }));
    return toCurrentUser(user);
  });

  await ensureAndAuditXuiUserGroup(actorId, user);

  return user;
}

export async function updateUser(
  actorId: string,
  id: string,
  input: Partial<Pick<ManagedUser, "name" | "telegram" | "telegramId" | "email" | "role" | "status" | "quotaConfigs">>,
) {
  return updateDb((db) => {
    const user = db.users.find((item) => item.id === id);
    if (!user) {
      return null;
    }

    if (input.name !== undefined) user.name = input.name;
    if (input.telegram !== undefined) user.telegram = input.telegram;
    if (input.telegramId !== undefined) user.telegramId = input.telegramId;
    if (input.email !== undefined) user.email = input.email;
    if (input.role === "admin" || input.role === "user") user.role = input.role;
    if (input.status === "active" || input.status === "blocked") user.status = input.status;
    if (input.quotaConfigs !== undefined) user.quotaConfigs = Math.max(0, Number(input.quotaConfigs));
    user.updatedAt = now();
    db.audit.push(makeAudit(actorId, "user.updated", "user", user.id, { quotaConfigs: user.quotaConfigs, status: user.status }));
    return toCurrentUser(user);
  });
}

export async function syncMissingXuiConnectionsForUser(ownerId: string) {
  const db = await readDb();
  const activeConfigs = db.configs.filter((config) => config.ownerId === ownerId && config.status === "active");
  if (!activeConfigs.length) {
    return { removed: 0 };
  }

  const checks = await Promise.all(
    activeConfigs.map(async (config) => ({
      id: config.id,
      state: await getXuiClientSyncState(config.externalClientId),
    })),
  );
  const missingIds = new Set(checks.filter((check) => check.state.state === "missing").map((check) => check.id));
  if (!missingIds.size) {
    return { removed: 0 };
  }

  return updateDb((nextDb) => {
    const removedConfigs = nextDb.configs.filter(
      (config) => config.ownerId === ownerId && config.status === "active" && missingIds.has(config.id),
    );
    if (!removedConfigs.length) {
      return { removed: 0 };
    }

    nextDb.configs = nextDb.configs.filter((config) => !removedConfigs.some((removed) => removed.id === config.id));

    const user = nextDb.users.find((item) => item.id === ownerId);
    if (user) {
      user.usedConfigs = countActiveConfigs(nextDb, ownerId);
      user.updatedAt = now();
    }

    for (const config of removedConfigs) {
      nextDb.audit.push(
        makeAudit("system", "config.synced_deleted", "config", config.id, {
          externalClientId: config.externalClientId,
        }),
      );
    }

    return { removed: removedConfigs.length };
  });
}

export async function listConnections(ownerId: string) {
  await syncMissingXuiConnectionsForUser(ownerId);
  const db = await readDb();
  return db.configs.filter((config) => config.ownerId === ownerId && config.status === "active").map(toConnection);
}

export async function getConnectionById(id: string, ownerId?: string) {
  if (ownerId) {
    await syncMissingXuiConnectionsForUser(ownerId);
  }

  const db = await readDb();
  const config = db.configs.find((item) => item.id === id && item.status === "active" && (!ownerId || item.ownerId === ownerId));
  return config ? toConnection(config) : null;
}

export async function getConnectionConfigText(id: string, ownerId?: string) {
  if (ownerId) {
    await syncMissingXuiConnectionsForUser(ownerId);
  }

  const db = await readDb();
  const config = db.configs.find((item) => item.id === id && (!ownerId || item.ownerId === ownerId));
  return config?.configText ?? null;
}

export async function createConnectionForUser(ownerId: string, input: CreateConnectionInput) {
  await syncMissingXuiConnectionsForUser(ownerId);

  return updateDb(async (db) => {
    const user = db.users.find((item) => item.id === ownerId);
    if (!user) {
      return { error: "user_not_found" as const };
    }
    if (user.status !== "active") {
      return { error: "user_blocked" as const };
    }
    if (user.usedConfigs >= user.quotaConfigs) {
      db.audit.push(
        makeAudit(ownerId, "config.create.denied_quota", "user", user.id, {
          usedConfigs: user.usedConfigs,
          quotaConfigs: user.quotaConfigs,
        }),
      );
      return { error: "quota_exceeded" as const, usedConfigs: user.usedConfigs, quotaConfigs: user.quotaConfigs };
    }
    if (input.protocol === "AmneziaWG") {
      return { error: "amneziawg_coming_later" as const };
    }

    const xuiGroupName = getUserXuiGroupName(user);
    const xuiClient = await createXuiClient({ ownerId, ownerEmail: user.email, ...input });
    const config: ManagedConfig = {
      id: `conn_${randomUUID()}`,
      ownerId,
      externalClientId: xuiClient.externalId,
      xuiGroupName,
      deviceName: input.deviceName.trim(),
      deviceType: input.deviceType,
      protocol: xuiClient.protocol,
      status: "active",
      createdAt: now(),
      connectUrl: xuiClient.connectUrl,
      configText: xuiClient.configText,
    };

    db.configs.push(config);
    user.usedConfigs += 1;
    user.updatedAt = now();
    db.audit.push(makeAudit(ownerId, "config.created", "config", config.id, { externalClientId: config.externalClientId, protocol: config.protocol }));
    return { connection: toConnection(config) };
  });
}

export async function revokeConnectionForUser(actorId: string, id: string, ownerId?: string) {
  return updateDb(async (db) => {
    const configIndex = db.configs.findIndex((item) => item.id === id && (!ownerId || item.ownerId === ownerId));
    const config = db.configs[configIndex];
    if (!config) {
      return null;
    }

    const wasActive = config.status === "active";
    const revokeResult = await revokeXuiClient(config.externalClientId);
    if (!revokeResult.ok) {
      db.audit.push(makeAudit(actorId, "config.delete.failed", "config", config.id, { externalClientId: config.externalClientId }));
      return { error: "remote_delete_failed" as const, id };
    }

    db.configs.splice(configIndex, 1);
    if (wasActive) {
      const user = db.users.find((item) => item.id === config.ownerId);
      if (user) {
        user.usedConfigs = Math.max(0, user.usedConfigs - 1);
        user.updatedAt = now();
      }
    }
    db.audit.push(makeAudit(actorId, "config.deleted", "config", config.id, { externalClientId: config.externalClientId }));
    return { ok: true, id };
  });
}

export async function getSubscriptionForUser(ownerId: string): Promise<Subscription | null> {
  await syncMissingXuiConnectionsForUser(ownerId);

  const db = await readDb();
  const user = db.users.find((item) => item.id === ownerId);
  if (!user) {
    return null;
  }

  const activeConnections = db.configs.filter((config) => config.ownerId === ownerId && config.status === "active").length;
  return {
    plan: user.quotaConfigs > 0 ? "Доступ выдан" : "Нет доступа",
    status: user.status === "active" && user.quotaConfigs > 0 ? "Активна" : "Неактивна",
    expiresAt: "без срока",
    daysLeft: 0,
    maxConnections: user.quotaConfigs,
    activeConnections,
    usedConnections: user.usedConfigs,
  };
}

export async function getActivePromoCodes() {
  const db = await readDb();
  return db.promoCodes.filter((promoCode) => promoCode.active);
}

export async function getManagedServers(): Promise<Server[]> {
  return [
    {
      id: "nas-v3",
      name: "NAS 3x-ui v3",
      location: "v3 only",
      protocols: ["vless"],
    },
  ];
}

export async function getAuditEvents(limit = 100) {
  const db = await readDb();
  return db.audit.slice(-limit).reverse();
}
