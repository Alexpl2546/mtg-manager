import { randomUUID } from "crypto";

import {
  analyzeXuiReadOnlySnapshot,
  analyzeXuiRunningConfig,
  createXuiReadOnlyClient,
  type XuiSnapshotExpectations,
} from "@/lib/server/xui-client";

export type XuiTestClientPlan = {
  execute: false;
  panelHost: string;
  generatedAt: string;
  readiness: {
    openapiOk: boolean;
    inboundsOk: boolean;
    targetInboundOk: boolean;
    targetInboundDetailOk: boolean;
    runningConfigOk: boolean;
    routingInboundTagOk: boolean;
    outboundTagOk: boolean;
    safeToRequestApproval: boolean;
  };
  targetInbound: {
    id?: number;
    remark?: string;
    port?: number;
    protocol?: string;
    tag?: string;
  };
  runningConfig: ReturnType<typeof analyzeXuiRunningConfig>;
  plannedMutation: {
    endpoint: "POST /panel/api/clients/add";
    payload: {
      client: {
        email: string;
        totalGB: number;
        expiryTime: number;
        tgId: number;
        limitIp: number;
        enable: true;
        remark: string;
      };
      inboundIds: number[];
    };
  };
  plannedGroupMutation: {
    endpoint: "POST /panel/api/clients/groups/bulkAdd";
    payload: {
      emails: string[];
      group: string;
    };
  };
  postCreateReadOnlyChecks: string[];
  rollbackPlan: {
    endpoint: "POST /panel/api/clients/del/{email}";
    email: string;
    executeOnlyIfExplicitlyApproved: true;
  };
  warnings: string[];
};

export type XuiTestClientPlanInput = {
  panelBaseUrl: string;
  apiToken?: string;
  sessionCookie?: string;
  expected: XuiSnapshotExpectations;
  label?: string;
  groupName?: string;
};

function safePlanLabel(label?: string) {
  return (label?.trim() || "codex-readiness")
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32) || "codex-readiness";
}

export async function buildXuiTestClientPlan(input: XuiTestClientPlanInput): Promise<XuiTestClientPlan> {
  const client = createXuiReadOnlyClient(input);
  const [openapi, inbounds, runningConfig] = await Promise.all([
    client.getOpenApi(),
    client.listInbounds(),
    client.getRunningXrayConfig(),
  ]);
  const target = inbounds.inbounds
    .map((inbound) => ({
      inbound,
      matchedBy: [
        inbound.remark === input.expected.inboundRemark ? "remark" : undefined,
        inbound.port === input.expected.inboundPort ? "port" : undefined,
      ].filter(Boolean),
    }))
    .sort((a, b) => b.matchedBy.length - a.matchedBy.length)
    .find((item) => item.matchedBy.length > 0);
  const targetInbound = target?.inbound.id ? await client.getInbound(target.inbound.id) : undefined;
  const snapshotAnalysis = analyzeXuiReadOnlySnapshot(
    {
      createdAt: new Date().toISOString(),
      panelHost: new URL(input.panelBaseUrl).host,
      openapi,
      inbounds,
      targetInbound,
    },
    input.expected,
  );
  const runningConfigAnalysis = analyzeXuiRunningConfig(runningConfig.data, input.expected);
  const warnings = [...snapshotAnalysis.warnings];
  const targetId = snapshotAnalysis.targetInbound.id;

  if (!targetId) {
    warnings.push("Planned client creation is blocked until target inbound id is known.");
  }

  if (!runningConfigAnalysis.expectedOutboundTagFound) {
    warnings.push("Expected outbound tag was not found in running Xray config.");
  }

  const email = `test-${safePlanLabel(input.label)}-${randomUUID().slice(0, 8)}@vpn-proxy-manager.local`;
  const groupName = input.groupName?.trim().toLowerCase() || "user@example.com";
  const readiness = {
    openapiOk: openapi.ok,
    inboundsOk: inbounds.ok,
    targetInboundOk: snapshotAnalysis.targetInbound.exactMatch,
    targetInboundDetailOk: Boolean(targetInbound?.ok),
    runningConfigOk: runningConfig.ok && runningConfigAnalysis.success,
    routingInboundTagOk: runningConfigAnalysis.expectedInboundTagFound,
    outboundTagOk: runningConfigAnalysis.expectedOutboundTagFound,
    safeToRequestApproval: false,
  };
  readiness.safeToRequestApproval =
    readiness.openapiOk &&
    readiness.inboundsOk &&
    readiness.targetInboundOk &&
    readiness.targetInboundDetailOk &&
    readiness.runningConfigOk &&
    readiness.routingInboundTagOk &&
    readiness.outboundTagOk;

  return {
    execute: false,
    panelHost: new URL(input.panelBaseUrl).host,
    generatedAt: new Date().toISOString(),
    readiness,
    targetInbound: {
      id: targetId,
      remark: snapshotAnalysis.targetInbound.remark,
      port: snapshotAnalysis.targetInbound.port,
      protocol: snapshotAnalysis.targetInbound.protocol,
      tag: snapshotAnalysis.targetInbound.tag,
    },
    runningConfig: runningConfigAnalysis,
    plannedMutation: {
      endpoint: "POST /panel/api/clients/add",
      payload: {
        client: {
          email,
          totalGB: 0,
          expiryTime: 0,
          tgId: 0,
          limitIp: 0,
          enable: true,
          remark: `Codex test ${safePlanLabel(input.label)}`,
        },
        inboundIds: targetId ? [targetId] : [],
      },
    },
    plannedGroupMutation: {
      endpoint: "POST /panel/api/clients/groups/bulkAdd",
      payload: {
        emails: [email],
        group: groupName,
      },
    },
    postCreateReadOnlyChecks: [
      "GET /panel/api/clients/get/{email}",
      "GET /panel/api/clients/links/{email}",
      "GET /api/admin/xui/diagnostics",
    ],
    rollbackPlan: {
      endpoint: "POST /panel/api/clients/del/{email}",
      email,
      executeOnlyIfExplicitlyApproved: true,
    },
    warnings,
  };
}
