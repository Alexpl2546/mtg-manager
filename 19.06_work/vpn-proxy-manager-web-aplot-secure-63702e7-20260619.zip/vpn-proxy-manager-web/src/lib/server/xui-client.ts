import { mkdir, writeFile } from "fs/promises";
import path from "path";

export type XuiApiEnvelope<T> = {
  success?: boolean;
  msg?: string;
  obj?: T;
};

export type XuiInbound = {
  id?: number;
  up?: number;
  down?: number;
  total?: number;
  remark?: string;
  enable?: boolean;
  expiryTime?: number;
  clientStats?: unknown[];
  listen?: string;
  port?: number;
  protocol?: string;
  settings?: string | Record<string, unknown>;
  streamSettings?: string | Record<string, unknown>;
  tag?: string;
  sniffing?: string | Record<string, unknown>;
};

export type XuiClientGroup = {
  name?: string;
  clientCount?: number;
};

export type XuiOpenApiSpec = {
  openapi?: string;
  info?: unknown;
  paths?: Record<string, unknown>;
};

export type XuiFetchResult<T> = {
  ok: boolean;
  status: number;
  data?: T;
};

export type XuiReadOnlyClientConfig = {
  panelBaseUrl: string;
  apiToken?: string;
  sessionCookie?: string;
};

export type XuiMutationClientConfig = XuiReadOnlyClientConfig;

export type XuiCreatePanelClientInput = {
  inboundId: number;
  email: string;
  remark: string;
  totalGB?: number;
  expiryTime?: number;
  tgId?: number;
  limitIp?: number;
};

export type XuiReadOnlySnapshot = {
  createdAt: string;
  panelHost: string;
  openapi: XuiFetchResult<XuiOpenApiSpec>;
  inbounds: XuiFetchResult<XuiApiEnvelope<XuiInbound[]> | XuiInbound[]>;
  targetInbound?: XuiFetchResult<XuiApiEnvelope<XuiInbound> | XuiInbound>;
};

export type XuiRunningConfigAnalysis = {
  success: boolean;
  inboundCount: number;
  outboundCount: number;
  routingRuleCount: number;
  expectedInboundTagFound: boolean;
  expectedOutboundTagFound: boolean;
  expectedInboundTagInInbounds: boolean;
  expectedOutboundTagInOutbounds: boolean;
};

export type XuiSnapshotExpectations = {
  inboundRemark: string;
  inboundPort: number;
  routingInboundTag: string;
  outboundTag: string;
};

export type XuiSnapshotAnalysis = {
  targetInbound: {
    found: boolean;
    id?: number;
    remark?: string;
    port?: number;
    protocol?: string;
    enabled?: boolean;
    tag?: string;
    matchedBy?: Array<"remark" | "port">;
    exactMatch: boolean;
  };
  parsed: {
    settings: boolean;
    streamSettings: boolean;
    sniffing: boolean;
  };
  stream?: {
    network?: unknown;
    security?: unknown;
  };
  checks: {
    openapiOk: boolean;
    inboundsOk: boolean;
    inboundRemarkOk: boolean;
    inboundPortOk: boolean;
    routingInboundTagFound: boolean;
    outboundTagFound: boolean;
  };
  warnings: string[];
};

function buildPanelUrl(baseUrl: string, relativePath: string) {
  return new URL(relativePath.replace(/^\//, ""), baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`);
}

function authHeaders(config: XuiReadOnlyClientConfig): HeadersInit {
  if (config.apiToken) {
    return { Authorization: `Bearer ${config.apiToken}` };
  }
  if (config.sessionCookie) {
    return { Cookie: config.sessionCookie };
  }
  return {};
}

async function fetchJson<T>(url: URL, headers: HeadersInit): Promise<XuiFetchResult<T>> {
  const response = await fetch(url, {
    headers,
    cache: "no-store",
  });

  let data: T | undefined;
  if (response.ok) {
    data = (await response.json()) as T;
  }

  return {
    ok: response.ok,
    status: response.status,
    data,
  };
}

async function sendJson<T>(url: URL, headers: HeadersInit, body: unknown): Promise<XuiFetchResult<T>> {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      ...headers,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    cache: "no-store",
  });

  let data: T | undefined;
  if (response.ok) {
    data = (await response.json()) as T;
  }

  return {
    ok: response.ok,
    status: response.status,
    data,
  };
}

export function unwrapInbounds(payload: unknown): XuiInbound[] {
  if (Array.isArray(payload)) {
    return payload as XuiInbound[];
  }

  const envelope = payload as XuiApiEnvelope<XuiInbound[]>;
  if (Array.isArray(envelope.obj)) {
    return envelope.obj;
  }

  return [];
}

export function unwrapInbound(payload: unknown): XuiInbound | undefined {
  if (!payload) {
    return undefined;
  }

  const direct = payload as XuiInbound;
  if (typeof direct.id === "number" || direct.remark || direct.port) {
    return direct;
  }

  const envelope = payload as XuiApiEnvelope<XuiInbound>;
  return envelope.obj;
}

function tryParseJson(value: unknown): unknown {
  if (value && typeof value === "object") {
    return value;
  }

  if (typeof value !== "string" || !value.trim()) {
    return undefined;
  }

  try {
    return JSON.parse(value) as unknown;
  } catch {
    return undefined;
  }
}

function readRecordValue(value: unknown, key: string) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return undefined;
  }

  return (value as Record<string, unknown>)[key];
}

function containsText(value: unknown, expected: string) {
  if (!expected) {
    return false;
  }

  return JSON.stringify(value ?? "").includes(expected);
}

function unwrapEnvelopeObject(payload: unknown) {
  const envelope = payload as XuiApiEnvelope<unknown>;
  return envelope.obj ?? payload;
}

function parsePossiblyJson(value: unknown) {
  if (typeof value !== "string") {
    return value;
  }

  try {
    return JSON.parse(value) as unknown;
  } catch {
    return value;
  }
}

function arrayRecordValue(value: unknown, key: string): unknown[] {
  const item = readRecordValue(value, key);
  return Array.isArray(item) ? item : [];
}

function matchTargetInbound(inbounds: XuiInbound[], remark: string, port: number) {
  return inbounds
    .map((inbound) => {
      const matchedBy: Array<"remark" | "port"> = [];
      if (inbound.remark === remark) matchedBy.push("remark");
      if (inbound.port === port) matchedBy.push("port");
      return { inbound, matchedBy };
    })
    .sort((a, b) => b.matchedBy.length - a.matchedBy.length)
    .find((item) => item.matchedBy.length > 0);
}

export function analyzeXuiReadOnlySnapshot(
  snapshot: XuiReadOnlySnapshot,
  expected: XuiSnapshotExpectations,
): XuiSnapshotAnalysis {
  const warnings: string[] = [];
  const inbounds = snapshot.inbounds.data ? unwrapInbounds(snapshot.inbounds.data) : [];
  const target = matchTargetInbound(inbounds, expected.inboundRemark, expected.inboundPort);
  const detailInbound = snapshot.targetInbound?.data ? unwrapInbound(snapshot.targetInbound.data) : undefined;
  const inbound = detailInbound ?? target?.inbound;
  const settings = tryParseJson(inbound?.settings);
  const streamSettings = tryParseJson(inbound?.streamSettings);
  const sniffing = tryParseJson(inbound?.sniffing);
  const inboundText = {
    tag: inbound?.tag,
    settings,
    streamSettings,
    sniffing,
  };
  const routingInboundTagFound =
    inbound?.tag === expected.routingInboundTag || containsText(inboundText, expected.routingInboundTag);
  const outboundTagFound = containsText(inboundText, expected.outboundTag);

  if (!target) {
    warnings.push("Target v3 inbound was not found by remark or port.");
  } else if (target.matchedBy.length < 2) {
    warnings.push("Target v3 inbound matched only partially; remark and port should both match.");
  }

  if (target && !routingInboundTagFound) {
    warnings.push("Expected routing inbound tag was not found in target inbound snapshot fields.");
  }

  return {
    targetInbound: {
      found: Boolean(target),
      id: inbound?.id,
      remark: inbound?.remark,
      port: inbound?.port,
      protocol: inbound?.protocol,
      enabled: inbound?.enable,
      tag: inbound?.tag,
      matchedBy: target?.matchedBy,
      exactMatch: target?.matchedBy.length === 2,
    },
    parsed: {
      settings: Boolean(settings),
      streamSettings: Boolean(streamSettings),
      sniffing: Boolean(sniffing),
    },
    stream: streamSettings
      ? {
          network: readRecordValue(streamSettings, "network"),
          security: readRecordValue(streamSettings, "security"),
        }
      : undefined,
    checks: {
      openapiOk: snapshot.openapi.ok,
      inboundsOk: snapshot.inbounds.ok,
      inboundRemarkOk: inbound?.remark === expected.inboundRemark,
      inboundPortOk: inbound?.port === expected.inboundPort,
      routingInboundTagFound,
      outboundTagFound,
    },
    warnings,
  };
}

export function analyzeXuiRunningConfig(payload: unknown, expected: XuiSnapshotExpectations): XuiRunningConfigAnalysis {
  const config = parsePossiblyJson(unwrapEnvelopeObject(payload));
  const inbounds = arrayRecordValue(config, "inbounds");
  const outbounds = arrayRecordValue(config, "outbounds");
  const routing = readRecordValue(config, "routing");
  const routingRules = arrayRecordValue(routing, "rules");
  const inboundTags = inbounds.map((item) => readRecordValue(item, "tag")).filter(Boolean);
  const outboundTags = outbounds.map((item) => readRecordValue(item, "tag")).filter(Boolean);
  const routingText = JSON.stringify(routing ?? "");

  return {
    success: Boolean(config && typeof config === "object"),
    inboundCount: inbounds.length,
    outboundCount: outbounds.length,
    routingRuleCount: routingRules.length,
    expectedInboundTagFound: inboundTags.includes(expected.routingInboundTag) || routingText.includes(expected.routingInboundTag),
    expectedOutboundTagFound: outboundTags.includes(expected.outboundTag) || routingText.includes(expected.outboundTag),
    expectedInboundTagInInbounds: inboundTags.includes(expected.routingInboundTag),
    expectedOutboundTagInOutbounds: outboundTags.includes(expected.outboundTag),
  };
}

export function createXuiReadOnlyClient(config: XuiReadOnlyClientConfig) {
  const headers = authHeaders(config);

  return {
    getOpenApi() {
      return fetchJson<XuiOpenApiSpec>(buildPanelUrl(config.panelBaseUrl, "api/openapi.json"), headers);
    },

    async listInbounds() {
      const result = await fetchJson<XuiApiEnvelope<XuiInbound[]> | XuiInbound[]>(
        buildPanelUrl(config.panelBaseUrl, "api/inbounds/list"),
        headers,
      );

      return {
        ...result,
        inbounds: result.data ? unwrapInbounds(result.data) : [],
      };
    },

    getInbound(id: number) {
      return fetchJson<XuiApiEnvelope<XuiInbound> | XuiInbound>(
        buildPanelUrl(config.panelBaseUrl, `api/inbounds/get/${id}`),
        headers,
      );
    },

    getRunningXrayConfig() {
      return fetchJson<XuiApiEnvelope<unknown>>(buildPanelUrl(config.panelBaseUrl, "api/server/getConfigJson"), headers);
    },

    getGroupEmails(group: string) {
      return fetchJson<XuiApiEnvelope<string[]>>(
        buildPanelUrl(config.panelBaseUrl, `api/clients/groups/${encodeURIComponent(group)}/emails`),
        headers,
      );
    },

    listGroups() {
      return fetchJson<XuiApiEnvelope<XuiClientGroup[]>>(buildPanelUrl(config.panelBaseUrl, "api/clients/groups"), headers);
    },

    async backupReadOnlySnapshot(
      options: {
        expected?: XuiSnapshotExpectations;
        snapshotDir?: string;
      } = {},
    ) {
      const [openapi, inbounds] = await Promise.all([
        this.getOpenApi(),
        fetchJson<XuiApiEnvelope<XuiInbound[]> | XuiInbound[]>(
          buildPanelUrl(config.panelBaseUrl, "api/inbounds/list"),
          headers,
        ),
      ]);
      const target = options.expected && inbounds.data
        ? matchTargetInbound(unwrapInbounds(inbounds.data), options.expected.inboundRemark, options.expected.inboundPort)
        : undefined;
      const targetInbound = target?.inbound.id ? await this.getInbound(target.inbound.id) : undefined;

      const snapshot: XuiReadOnlySnapshot = {
        createdAt: new Date().toISOString(),
        panelHost: new URL(config.panelBaseUrl).host,
        openapi,
        inbounds,
        targetInbound,
      };

      const snapshotDir = options.snapshotDir ?? path.join(process.cwd(), ".local-data", "xui-snapshots");
      await mkdir(snapshotDir, { recursive: true });
      const fileName = `xui-readonly-${snapshot.createdAt.replace(/[:.]/g, "-")}.json`;
      const filePath = path.join(snapshotDir, fileName);
      await writeFile(filePath, `${JSON.stringify(snapshot, null, 2)}\n`, "utf8");

      return { filePath, snapshot };
    },
  };
}

export function createXuiMutationClient(config: XuiMutationClientConfig) {
  const readOnlyClient = createXuiReadOnlyClient(config);
  const headers = authHeaders(config);

  return {
    ...readOnlyClient,

    createClient(input: XuiCreatePanelClientInput) {
      return sendJson<XuiApiEnvelope<unknown>>(buildPanelUrl(config.panelBaseUrl, "api/clients/add"), headers, {
        client: {
          email: input.email,
          totalGB: input.totalGB ?? 0,
          expiryTime: input.expiryTime ?? 0,
          tgId: input.tgId ?? 0,
          limitIp: input.limitIp ?? 0,
          enable: true,
          remark: input.remark,
        },
        inboundIds: [input.inboundId],
      });
    },

    addClientsToGroup(emails: string[], group: string) {
      return sendJson<XuiApiEnvelope<unknown>>(buildPanelUrl(config.panelBaseUrl, "api/clients/groups/bulkAdd"), headers, {
        emails,
        group,
      });
    },

    createGroup(name: string) {
      return sendJson<XuiApiEnvelope<unknown>>(buildPanelUrl(config.panelBaseUrl, "api/clients/groups/create"), headers, {
        name,
      });
    },

    deleteGroup(name: string) {
      return sendJson<XuiApiEnvelope<unknown>>(buildPanelUrl(config.panelBaseUrl, "api/clients/groups/delete"), headers, {
        name,
      });
    },

    getClient(email: string) {
      return fetchJson<XuiApiEnvelope<unknown>>(
        buildPanelUrl(config.panelBaseUrl, `api/clients/get/${encodeURIComponent(email)}`),
        headers,
      );
    },

    getClientLinks(email: string) {
      return fetchJson<XuiApiEnvelope<string[]>>(
        buildPanelUrl(config.panelBaseUrl, `api/clients/links/${encodeURIComponent(email)}`),
        headers,
      );
    },

    deleteClient(email: string, keepTraffic = false) {
      const url = buildPanelUrl(config.panelBaseUrl, `api/clients/del/${encodeURIComponent(email)}`);
      url.searchParams.set("keepTraffic", keepTraffic ? "1" : "0");

      return sendJson<XuiApiEnvelope<unknown>>(url, headers, {});
    },
  };
}
