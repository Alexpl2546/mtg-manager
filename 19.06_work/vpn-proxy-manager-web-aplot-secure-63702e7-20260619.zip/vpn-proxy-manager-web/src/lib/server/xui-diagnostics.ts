import { createXuiReadOnlyClient, type XuiInbound } from "@/lib/server/xui-client";

export type XuiDiagnostics = {
  configured: boolean;
  panelHost?: string;
  authMode: "api-token" | "session-cookie" | "none";
  openapi: {
    checked: boolean;
    ok: boolean;
    status?: number;
    pathsCount?: number;
    error?: string;
  };
  inbounds: {
    checked: boolean;
    ok: boolean;
    status?: number;
    total?: number;
    error?: string;
  };
  targetInbound: {
    found: boolean;
    id?: number;
    remark?: string;
    port?: number;
    protocol?: string;
    enabled?: boolean;
    tag?: string;
    matchedBy?: Array<"remark" | "port">;
  };
  expected: {
    inboundRemark?: string;
    inboundPort?: number;
    routingInboundTag?: string;
    outboundTag?: string;
  };
  warnings: string[];
};

export function getXuiExpectedConfig() {
  const inboundRemark = process.env.XUI_TARGET_INBOUND_REMARK?.trim() || "vless-reality-v3-24443";
  const inboundPort = Number(process.env.XUI_TARGET_INBOUND_PORT || 24443);

  return {
    inboundRemark,
    inboundPort: Number.isFinite(inboundPort) ? inboundPort : 24443,
    routingInboundTag: process.env.XUI_EXPECTED_ROUTING_INBOUND_TAG?.trim() || "in-24443-tcp",
    outboundTag: process.env.XUI_EXPECTED_OUTBOUND_TAG?.trim() || "VLESS-Reality-home_v3",
  };
}

function getConfig() {
  const panelBaseUrl = process.env.XUI_PANEL_BASE_URL?.trim();
  const apiToken = process.env.XUI_API_TOKEN?.trim();
  const sessionCookie = process.env.XUI_SESSION_COOKIE?.trim();

  return {
    panelBaseUrl,
    apiToken,
    sessionCookie,
    ...getXuiExpectedConfig(),
  };
}

function sanitizeError(error: unknown) {
  if (error instanceof Error) {
    return error.message.replace(/https?:\/\/\S+/g, "[url]");
  }
  return "Unknown error";
}

export function matchTargetInbound(inbounds: XuiInbound[], remark: string, port: number) {
  return inbounds
    .map((inbound) => {
      const matchedBy: Array<"remark" | "port"> = [];
      if (inbound.remark === remark) matchedBy.push("remark");
      if (inbound.port === port) matchedBy.push("port");
      return { inbound, matchedBy };
    })
    .sort((a, b) => b.matchedBy.length - a.matchedBy.length)
    .find((item) => item.matchedBy.length > 0);
}

export async function runXuiReadOnlyDiagnostics(): Promise<XuiDiagnostics> {
  const config = getConfig();
  const warnings: string[] = [];
  const authMode = config.apiToken ? "api-token" : config.sessionCookie ? "session-cookie" : "none";

  const diagnostics: XuiDiagnostics = {
    configured: Boolean(config.panelBaseUrl),
    panelHost: config.panelBaseUrl ? new URL(config.panelBaseUrl).host : undefined,
    authMode,
    openapi: { checked: false, ok: false },
    inbounds: { checked: false, ok: false },
    targetInbound: { found: false },
    expected: {
      inboundRemark: config.inboundRemark,
      inboundPort: config.inboundPort,
      routingInboundTag: config.routingInboundTag,
      outboundTag: config.outboundTag,
    },
    warnings,
  };

  if (!config.panelBaseUrl) {
    warnings.push("XUI_PANEL_BASE_URL is not configured.");
    return diagnostics;
  }

  if (!config.panelBaseUrl.includes("homepanel-v3.route98.netcraze.pro")) {
    warnings.push("Panel URL is not the expected v3 NAS panel host.");
    return diagnostics;
  }

  if (authMode === "none") {
    warnings.push("XUI_API_TOKEN or XUI_SESSION_COOKIE is required for authenticated diagnostics.");
  }

  const client = createXuiReadOnlyClient({
    panelBaseUrl: config.panelBaseUrl,
    apiToken: config.apiToken,
    sessionCookie: config.sessionCookie,
  });

  try {
    const response = await client.getOpenApi();
    diagnostics.openapi.checked = true;
    diagnostics.openapi.status = response.status;
    diagnostics.openapi.ok = response.ok;

    if (response.ok) {
      const spec = response.data;
      diagnostics.openapi.pathsCount = spec?.paths ? Object.keys(spec.paths).length : 0;
    }
  } catch (error) {
    diagnostics.openapi.checked = true;
    diagnostics.openapi.error = sanitizeError(error);
  }

  try {
    const response = await client.listInbounds();
    diagnostics.inbounds.checked = true;
    diagnostics.inbounds.status = response.status;
    diagnostics.inbounds.ok = response.ok;

    if (response.ok) {
      const target = matchTargetInbound(response.inbounds, config.inboundRemark, config.inboundPort);
      diagnostics.inbounds.total = response.inbounds.length;

      if (target) {
        diagnostics.targetInbound = {
          found: true,
          id: target.inbound.id,
          remark: target.inbound.remark,
          port: target.inbound.port,
          protocol: target.inbound.protocol,
          enabled: target.inbound.enable,
          tag: target.inbound.tag,
          matchedBy: target.matchedBy,
        };
      } else {
        warnings.push("Target v3 inbound was not found by remark or port.");
      }
    }
  } catch (error) {
    diagnostics.inbounds.checked = true;
    diagnostics.inbounds.error = sanitizeError(error);
  }

  return diagnostics;
}
