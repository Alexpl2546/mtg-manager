import { cookies } from "next/headers";

import {
  createConnectionForUser,
  getConnectionById,
  getConnectionConfigText,
  getManagedServers,
  getSubscriptionForUser,
  getUserBySessionToken,
  listConnections,
  loginUser,
  revokeConnectionForUser,
} from "@/lib/server/vpn-store";
import type { Connection, CreateConnectionInput, DeviceType, Server } from "@/lib/types";

const backendUrl = process.env.VPN_BACKEND_URL?.replace(/\/$/, "");
const backendToken = process.env.VPN_BACKEND_TOKEN;

type BackendSubscription = {
  plan: string;
  status: "active" | "inactive" | "expiring";
  expiresAt: string;
  maxConnections: number;
  activeConnections: number;
};

type BackendConnection = Omit<Connection, "deviceType"> & {
  deviceType?: string;
};

function normalizeDeviceType(value: string | undefined): DeviceType {
  const normalized = value?.trim().toLowerCase();
  if (normalized === "телефон" || normalized === "phone" || normalized === "mobile") {
    return "Телефон";
  }
  if (normalized === "телевизор" || normalized === "tv" || normalized === "android tv") {
    return "Телевизор";
  }
  if (normalized === "роутер" || normalized === "router") {
    return "Роутер";
  }

  return "Компьютер";
}

function normalizeConnection(connection: BackendConnection): Connection {
  return {
    ...connection,
    deviceType: normalizeDeviceType(connection.deviceType),
  };
}

async function backendFetch<T>(path: string, init?: RequestInit): Promise<T | null> {
  if (!backendUrl) {
    return null;
  }

  try {
    const response = await fetch(`${backendUrl}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(backendToken ? { Authorization: `Bearer ${backendToken}` } : {}),
        ...init?.headers,
      },
      cache: "no-store",
    });

    if (!response.ok) {
      return null;
    }

    return (await response.json()) as T;
  } catch {
    return null;
  }
}

export async function getCurrentUser() {
  const backendUser = await backendFetch<Awaited<ReturnType<typeof getUserBySessionToken>>>("/me");
  if (backendUser) {
    return backendUser;
  }

  const sessionToken = (await cookies()).get("vpn_session")?.value;
  return getUserBySessionToken(sessionToken);
}

export async function getSubscription() {
  const backendSubscription = await backendFetch<BackendSubscription>("/subscription");
  if (backendSubscription) {
    return {
      plan: backendSubscription.plan,
      status:
        backendSubscription.status === "active"
          ? "Активна"
          : backendSubscription.status === "expiring"
            ? "Истекает"
            : "Неактивна",
      expiresAt: backendSubscription.expiresAt,
      daysLeft: 0,
      maxConnections: backendSubscription.maxConnections,
      activeConnections: backendSubscription.activeConnections,
    };
  }

  const user = await getCurrentUser();
  const storeSubscription = user ? await getSubscriptionForUser(user.id) : null;
  if (storeSubscription) {
    return storeSubscription;
  }

  return null;
}

export async function getConnections() {
  const backendConnections = await backendFetch<BackendConnection[]>("/configs");
  if (backendConnections) {
    return backendConnections.map(normalizeConnection);
  }

  const user = await getCurrentUser();
  if (user) {
    return listConnections(user.id);
  }

  return [];
}

export async function getConnection(id: string) {
  const backendConnection = await backendFetch<BackendConnection>(`/configs/${id}`);
  if (backendConnection) {
    return normalizeConnection(backendConnection);
  }

  const user = await getCurrentUser();
  const storeConnection = user ? await getConnectionById(id, user.id) : null;
  if (storeConnection) {
    return storeConnection;
  }

  return null;
}

export async function getServers(): Promise<Server[]> {
  const backendServers = await backendFetch<Server[]>("/servers");
  if (backendServers) {
    return backendServers;
  }

  return getManagedServers();
}

export async function login(identifier: string, password: string) {
  const backendLogin = await backendFetch<{ token: string; tokenType: string }>("/auth/login", {
    method: "POST",
    body: JSON.stringify({ identifier, password }),
  });
  if (backendLogin) {
    return backendLogin;
  }

  const storeLogin = await loginUser(identifier, password);
  if (storeLogin) {
    return storeLogin;
  }

  return null;
}

export async function createConnection(input: CreateConnectionInput): Promise<Connection> {
  const protocol = input.protocol === "AmneziaWG" ? "amneziawg" : "vless";
  const backendConnection = await backendFetch<BackendConnection>("/configs", {
    method: "POST",
    body: JSON.stringify({
      deviceName: input.deviceName,
      deviceType: input.deviceType,
      protocol,
    }),
  });
  if (backendConnection) {
    return normalizeConnection(backendConnection);
  }

  const user = await getCurrentUser();
  if (user) {
    const result = await createConnectionForUser(user.id, input);
    if ("connection" in result && result.connection) {
      return result.connection;
    }

    throw new Error(result.error);
  }

  throw new Error("unauthorized");
}

export async function revokeConnection(id: string) {
  const backendResult = await backendFetch<{ ok?: boolean; id?: string }>(`/configs/${id}/revoke`, {
    method: "POST",
  });
  if (backendResult) {
    return { ok: true, id };
  }

  const user = await getCurrentUser();
  const storeResult = user ? await revokeConnectionForUser(user.id, id, user.id) : null;
  if (storeResult) {
    return storeResult;
  }

  return { ok: false, id };
}

export async function getConnectionQr(id: string) {
  const backendQr = await backendFetch<{ value: string }>(`/configs/${id}/qr`);
  if (backendQr) {
    return backendQr.value;
  }

  const user = await getCurrentUser();
  const storeConnection = user ? await getConnectionById(id, user.id) : null;
  if (storeConnection) {
    return storeConnection.connectUrl;
  }

  return null;
}

export async function downloadConnectionConfig(id: string) {
  if (backendUrl) {
    try {
      const response = await fetch(`${backendUrl}/configs/${id}/download`, {
        headers: backendToken ? { Authorization: `Bearer ${backendToken}` } : {},
        cache: "no-store",
      });
      if (response.ok) {
        return response.text();
      }
    } catch {
      // Fall back to the local store below.
    }
  }

  const user = await getCurrentUser();
  const storeText = user ? await getConnectionConfigText(id, user.id) : null;
  if (storeText) {
    return storeText;
  }

  return null;
}
