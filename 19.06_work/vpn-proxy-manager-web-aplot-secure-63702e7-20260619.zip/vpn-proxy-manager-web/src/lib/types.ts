export type Protocol = "VLESS Reality" | "AmneziaWG";
export type ProtocolChoice = Protocol;
export type DeviceType = "Телефон" | "Компьютер" | "Телевизор" | "Роутер";
export type ConnectionStatus = "Подключено" | "Ожидает настройки" | "Отключено";

export type CurrentUser = {
  id: string;
  name: string;
  telegram?: string;
  phone?: string;
  email?: string;
  avatarFallback: string;
  role?: "admin" | "user";
  status?: "active" | "blocked";
  quotaConfigs?: number;
  usedConfigs?: number;
  twoFactorEnabled?: boolean;
};

export type Subscription = {
  plan: string;
  status: "Активна" | "Истекает" | "Неактивна";
  expiresAt: string;
  daysLeft: number;
  maxConnections: number;
  activeConnections: number;
  usedConnections?: number;
};

export type Connection = {
  id: string;
  ownerId?: string;
  deviceName: string;
  deviceType: DeviceType;
  protocol: Protocol;
  status: ConnectionStatus;
  createdAt: string;
  lastUsedAt: string;
  configUrl: string;
  connectUrl: string;
};

export type CreateConnectionInput = {
  deviceType: DeviceType;
  deviceName: string;
  protocol: ProtocolChoice;
};

export type Server = {
  id: string;
  name: string;
  location: string;
  protocols: Array<"vless" | "amneziawg">;
};
