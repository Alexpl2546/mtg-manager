import { redirect } from "next/navigation";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LogoutButton } from "@/components/app/logout-button";
import { getCurrentUser } from "@/lib/api";

export default async function ProfilePage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Профиль</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Аккаунт</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 bg-[linear-gradient(160deg,var(--brand-cyan),var(--brand-blue))] shadow-[0_0_24px_oklch(0.62_0.19_252_/_0.24)]">
              <AvatarFallback>{user.avatarFallback}</AvatarFallback>
            </Avatar>
            <div>
              <div className="text-xl font-semibold">{user.name}</div>
              <div className="text-sm text-muted-foreground">{user.email ?? user.phone ?? "Контакт не указан"}</div>
            </div>
          </div>
          <ProfileRow label="Имя" value={user.name} />
          <ProfileRow label="Телефон" value={user.phone ?? "не указан"} />
          <ProfileRow label="Email" value={user.email ?? "не указан"} />
          <ProfileRow label="Двухфакторная защита">
            <span className={user.twoFactorEnabled ? "font-semibold text-cyan-100" : "font-semibold text-destructive"}>
              {user.twoFactorEnabled ? "включена" : "отключена"}
            </span>
          </ProfileRow>
          <LogoutButton />
        </CardContent>
      </Card>
    </div>
  );
}

function ProfileRow({ label, value, children }: { label: string; value?: string; children?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-t border-border pt-4">
      <span className="text-muted-foreground">{label}</span>
      {children ?? <span className="font-semibold">{value}</span>}
    </div>
  );
}
