import { Crown } from "lucide-react";
import { redirect } from "next/navigation";

import { SubscriptionPricing } from "@/components/app/subscription-pricing";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getCurrentUser, getSubscription } from "@/lib/api";
import { getActivePromoCodes } from "@/lib/server/vpn-store";

export default async function SubscriptionPage() {
  const [user, subscription, promoCodes] = await Promise.all([getCurrentUser(), getSubscription(), getActivePromoCodes()]);
  if (!user) {
    redirect("/login");
  }
  if (!subscription) {
    redirect("/profile");
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Подписка</h1>
      </div>
      <section className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        <Card className="brand-panel border-primary/30 bg-[linear-gradient(135deg,oklch(0.2_0.05_252_/_0.96),oklch(0.14_0.035_255_/_0.96))]">
          <CardHeader>
            <div className="flex items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-3">
                <Crown className="h-6 w-6 text-cyan-100" />
                {subscription.plan}
              </CardTitle>
              <Badge variant={subscription.status === "Неактивна" ? "danger" : "success"}>{subscription.status}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-5 pt-6">
            <Row label="Дата окончания" value={subscription.expiresAt} />
            <Row label="Осталось" value={`${subscription.daysLeft} дня`} />
            <Row label="Подключённых устройств" value={`${subscription.activeConnections} из ${subscription.maxConnections}`} />
            <Progress value={subscription.maxConnections ? (subscription.activeConnections / subscription.maxConnections) * 100 : 0} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Варианты оплаты</CardTitle>
          </CardHeader>
          <CardContent>
            <SubscriptionPricing promoCodes={promoCodes} />
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-border pb-4">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}
