"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Mail, Phone } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const nextIdentifier = String(formData.get("identifier") ?? "").trim();
    const nextPassword = String(formData.get("password") ?? "");

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: nextIdentifier, password: nextPassword }),
      });

      if (!response.ok) {
        setError("Проверьте email, телефон и пароль.");
        return;
      }

      router.push("/");
      router.refresh();
    } catch {
      setError("Не удалось выполнить вход. Проверьте подключение и попробуйте снова.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <Card className="brand-panel w-full max-w-md">
        <CardHeader>
          <span className="brand-mark mb-4" aria-hidden="true" />
          <CardTitle>Вход в APlot Secure</CardTitle>
        </CardHeader>
        <CardContent>
          <form action="/api/auth/login" className="space-y-4" method="post" onSubmit={submit}>
            <div className="space-y-2">
              <Label htmlFor="identifier">Email или телефон</Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Phone className="pointer-events-none absolute left-9 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="identifier"
                  name="identifier"
                  autoComplete="username"
                  className="pl-16"
                  value={identifier}
                  onChange={(event) => setIdentifier(event.target.value)}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Пароль</Label>
              <Input
                id="password"
                name="password"
                autoComplete="current-password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
              />
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <Button className="w-full" disabled={loading} type="submit">
              {loading ? "Входим..." : "Войти"}
            </Button>
          </form>
          <div className="mt-5 text-center text-sm text-muted-foreground">
            Нет аккаунта?{" "}
            <Link className="font-semibold text-foreground hover:text-primary" href="/register">
              Зарегистрироваться
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
