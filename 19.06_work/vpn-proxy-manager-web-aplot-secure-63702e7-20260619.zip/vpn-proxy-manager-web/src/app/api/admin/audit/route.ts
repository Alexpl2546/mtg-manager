import { NextResponse } from "next/server";

import { requireAdmin } from "@/lib/server/request-auth";
import { getAuditEvents } from "@/lib/server/vpn-store";

export async function GET(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  return NextResponse.json(await getAuditEvents());
}
