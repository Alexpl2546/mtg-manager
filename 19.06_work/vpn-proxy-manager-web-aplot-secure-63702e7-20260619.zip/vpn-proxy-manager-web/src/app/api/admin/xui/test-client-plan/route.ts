import { NextResponse } from "next/server";

import { requireAdmin } from "@/lib/server/request-auth";
import { getXuiExpectedConfig } from "@/lib/server/xui-diagnostics";
import { buildXuiTestClientPlan } from "@/lib/server/xui-test-client-plan";

function getXuiConfig() {
  return {
    panelBaseUrl: process.env.XUI_PANEL_BASE_URL?.trim(),
    apiToken: process.env.XUI_API_TOKEN?.trim(),
    sessionCookie: process.env.XUI_SESSION_COOKIE?.trim(),
  };
}

export async function POST(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  const config = getXuiConfig();
  if (!config.panelBaseUrl) {
    return NextResponse.json({ configured: false, warning: "XUI_PANEL_BASE_URL is not configured." }, { status: 400 });
  }

  if (!config.apiToken && !config.sessionCookie) {
    return NextResponse.json(
      { configured: false, warning: "XUI_API_TOKEN or XUI_SESSION_COOKIE is required." },
      { status: 400 },
    );
  }

  if (!config.panelBaseUrl.includes("homepanel-v3.route98.netcraze.pro")) {
    return NextResponse.json(
      { configured: false, warning: "Panel URL is not the expected v3 NAS panel host." },
      { status: 400 },
    );
  }

  const body = (await request.json().catch(() => ({}))) as { label?: string; groupName?: string; ownerEmail?: string };
  const plan = await buildXuiTestClientPlan({
    panelBaseUrl: config.panelBaseUrl,
    apiToken: config.apiToken,
    sessionCookie: config.sessionCookie,
    expected: getXuiExpectedConfig(),
    label: body.label,
    groupName: body.groupName ?? body.ownerEmail,
  });

  return NextResponse.json(plan);
}
