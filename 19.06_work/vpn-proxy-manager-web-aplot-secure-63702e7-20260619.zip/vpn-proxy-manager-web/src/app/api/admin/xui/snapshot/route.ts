import { NextResponse } from "next/server";

import { analyzeXuiReadOnlySnapshot, createXuiReadOnlyClient, unwrapInbounds } from "@/lib/server/xui-client";
import { requireAdmin } from "@/lib/server/request-auth";
import { getXuiExpectedConfig } from "@/lib/server/xui-diagnostics";

function getSnapshotConfig() {
  const panelBaseUrl = process.env.XUI_PANEL_BASE_URL?.trim();
  const apiToken = process.env.XUI_API_TOKEN?.trim();
  const sessionCookie = process.env.XUI_SESSION_COOKIE?.trim();

  return {
    panelBaseUrl,
    apiToken,
    sessionCookie,
  };
}

export async function POST(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  const config = getSnapshotConfig();
  if (!config.panelBaseUrl) {
    return NextResponse.json(
      {
        configured: false,
        warning: "XUI_PANEL_BASE_URL is not configured.",
      },
      { status: 400 },
    );
  }

  if (!config.apiToken && !config.sessionCookie) {
    return NextResponse.json(
      {
        configured: false,
        warning: "XUI_API_TOKEN or XUI_SESSION_COOKIE is required for read-only snapshot.",
      },
      { status: 400 },
    );
  }

  if (!config.panelBaseUrl.includes("homepanel-v3.route98.netcraze.pro")) {
    return NextResponse.json(
      {
        configured: false,
        warning: "Panel URL is not the expected v3 NAS panel host.",
      },
      { status: 400 },
    );
  }

  const client = createXuiReadOnlyClient({
    panelBaseUrl: config.panelBaseUrl,
    apiToken: config.apiToken,
    sessionCookie: config.sessionCookie,
  });

  const expected = getXuiExpectedConfig();
  const result = await client.backupReadOnlySnapshot({ expected });
  const analysis = analyzeXuiReadOnlySnapshot(result.snapshot, expected);
  const inboundCount = result.snapshot.inbounds.data ? unwrapInbounds(result.snapshot.inbounds.data).length : 0;

  return NextResponse.json({
    configured: true,
    panelHost: result.snapshot.panelHost,
    filePath: result.filePath,
    openapi: {
      ok: result.snapshot.openapi.ok,
      status: result.snapshot.openapi.status,
      pathsCount: result.snapshot.openapi.data?.paths
        ? Object.keys(result.snapshot.openapi.data.paths).length
        : undefined,
    },
    inbounds: {
      ok: result.snapshot.inbounds.ok,
      status: result.snapshot.inbounds.status,
      total: inboundCount,
    },
    targetInboundDetail: result.snapshot.targetInbound
      ? {
          ok: result.snapshot.targetInbound.ok,
          status: result.snapshot.targetInbound.status,
        }
      : undefined,
    analysis,
  });
}
