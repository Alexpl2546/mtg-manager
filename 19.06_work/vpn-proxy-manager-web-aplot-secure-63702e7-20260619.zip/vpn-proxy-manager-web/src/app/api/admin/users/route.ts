import { NextResponse } from "next/server";

import { requireAdmin } from "@/lib/server/request-auth";
import { createUser, listUsers } from "@/lib/server/vpn-store";

export async function GET(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  return NextResponse.json(await listUsers());
}

export async function POST(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  const input = (await request.json()) as {
    name?: string;
    telegram?: string;
    telegramId?: string;
    email?: string;
    role?: "admin" | "user";
    status?: "active" | "blocked";
    quotaConfigs?: number;
  };

  if (!input.name?.trim() || !input.telegram?.trim()) {
    return NextResponse.json({ error: "name and telegram are required" }, { status: 400 });
  }

  const user = await createUser(admin.actorId, {
    name: input.name.trim(),
    telegram: input.telegram.trim(),
    telegramId: input.telegramId?.trim(),
    email: input.email?.trim(),
    role: input.role,
    status: input.status,
    quotaConfigs: input.quotaConfigs,
  });

  return NextResponse.json(user, { status: 201 });
}
