import { NextResponse } from "next/server";

import { requireAdmin } from "@/lib/server/request-auth";
import { updateUser } from "@/lib/server/vpn-store";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin(request);
  if (!admin.ok) {
    return NextResponse.json({ error: admin.error }, { status: admin.status });
  }

  const { id } = await params;
  const input = (await request.json()) as {
    name?: string;
    telegram?: string;
    telegramId?: string;
    email?: string;
    role?: "admin" | "user";
    status?: "active" | "blocked";
    quotaConfigs?: number;
  };

  const user = await updateUser(admin.actorId, id, input);
  if (!user) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json(user);
}
