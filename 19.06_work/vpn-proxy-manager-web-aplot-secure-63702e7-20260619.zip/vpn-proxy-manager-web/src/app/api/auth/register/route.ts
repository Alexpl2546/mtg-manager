import { NextResponse } from "next/server";

import { registerUser } from "@/lib/server/vpn-store";

export async function POST(request: Request) {
  const input = (await request.json()) as {
    name: string;
    email: string;
    phone?: string;
    password: string;
  };

  const result = await registerUser(input);
  if ("error" in result) {
    const status = result.error === "email_exists" || result.error === "phone_exists" ? 409 : 400;
    return NextResponse.json(result, { status });
  }

  const response = NextResponse.json({
    user: result.user,
    tokenType: result.tokenType,
    expiresAt: result.expiresAt,
    twoFactorRequired: false,
  }, { status: 201 });
  response.cookies.set("vpn_session", result.token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(result.expiresAt),
  });

  return response;
}
