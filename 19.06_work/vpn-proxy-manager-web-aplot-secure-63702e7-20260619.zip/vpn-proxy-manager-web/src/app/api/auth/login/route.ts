import { NextResponse } from "next/server";

import { loginUser } from "@/lib/server/vpn-store";

export async function POST(request: Request) {
  const contentType = request.headers.get("content-type") ?? "";
  const isFormPost = contentType.includes("application/x-www-form-urlencoded") || contentType.includes("multipart/form-data");
  const input = isFormPost
    ? Object.fromEntries(await request.formData())
    : ((await request.json()) as {
        identifier?: string;
        email?: string;
        phone?: string;
        password?: string;
      });
  const identifier = String(input.identifier ?? input.email ?? input.phone ?? "");
  const password = String(input.password ?? "");

  const result = await loginUser(identifier, password);
  if (!result) {
    if (isFormPost) {
      return NextResponse.redirect(new URL("/login?error=invalid", request.url), { status: 303 });
    }

    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  const response = isFormPost
    ? NextResponse.redirect(new URL("/", request.url), { status: 303 })
    : NextResponse.json({
        user: result.user,
        tokenType: result.tokenType,
        expiresAt: result.expiresAt,
        twoFactorRequired: result.twoFactorRequired,
      });
  response.cookies.set("vpn_session", result.token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(result.expiresAt),
  });

  return response;
}
