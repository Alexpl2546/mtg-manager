import { NextRequest, NextResponse } from "next/server";

import { revokeSessionToken } from "@/lib/server/vpn-store";

export async function POST(request: NextRequest) {
  const token = request.cookies.get("vpn_session")?.value;
  await revokeSessionToken(token);

  const response = NextResponse.json({ ok: true });
  response.cookies.set("vpn_session", "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });

  return response;
}
