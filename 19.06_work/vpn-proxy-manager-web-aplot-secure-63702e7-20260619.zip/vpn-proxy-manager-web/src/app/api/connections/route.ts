import { NextResponse } from "next/server";

import { getRequestUser } from "@/lib/server/request-auth";
import { createConnectionForUser, listConnections } from "@/lib/server/vpn-store";
import type { CreateConnectionInput } from "@/lib/types";

export async function GET(request: Request) {
  const user = await getRequestUser(request);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json(await listConnections(user.id));
}

export async function POST(request: Request) {
  const user = await getRequestUser(request);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const input = (await request.json()) as CreateConnectionInput;
  const result = await createConnectionForUser(user.id, input);

  if ("connection" in result && result.connection) {
    return NextResponse.json(result.connection, { status: 201 });
  }

  return NextResponse.json(result, { status: result.error === "quota_exceeded" ? 403 : 400 });
}
