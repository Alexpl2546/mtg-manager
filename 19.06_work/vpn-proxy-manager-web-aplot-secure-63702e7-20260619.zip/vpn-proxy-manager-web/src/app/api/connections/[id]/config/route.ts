import { getRequestUser } from "@/lib/server/request-auth";
import { getConnectionConfigText } from "@/lib/server/vpn-store";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getRequestUser(request);
  if (!user) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { id } = await params;
  const body = await getConnectionConfigText(id, user.id);
  if (!body) {
    return new Response("Not found", { status: 404 });
  }

  return new Response(body, {
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Disposition": `attachment; filename="${id}.conf"`,
    },
  });
}
