import { NextResponse } from "next/server";

import { getRequestUser } from "@/lib/server/request-auth";
import { getConnectionById } from "@/lib/server/vpn-store";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getRequestUser(request);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const connection = await getConnectionById(id, user.id);
  if (!connection) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ value: connection.connectUrl });
}
