import { NextResponse } from "next/server";

import { getManagedServers } from "@/lib/server/vpn-store";

export async function GET() {
  return NextResponse.json(await getManagedServers());
}
