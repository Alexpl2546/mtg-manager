import { NextResponse } from "next/server";

import { getRequestUser } from "@/lib/server/request-auth";
import { getSubscriptionForUser } from "@/lib/server/vpn-store";

export async function GET(request: Request) {
  const user = await getRequestUser(request);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const subscription = await getSubscriptionForUser(user.id);
  if (!subscription) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json(subscription);
}
