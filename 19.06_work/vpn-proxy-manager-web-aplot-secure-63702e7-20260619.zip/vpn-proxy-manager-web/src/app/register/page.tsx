"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, phone, password }),
    });

    setLoading(false);
    if (!response.ok) {
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      setError(
        payload?.error === "email_exists"
          ? "Пользователь с таким email уже есть."
          : payload?.error === "phone_exists"
            ? "Пользователь с таким телефоном уже есть."
            : "Не удалось создать аккаунт.",
      );
      return;
    }

    router.push("/");
    router.refresh();
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <Card className="brand-panel w-full max-w-md">
        <CardHeader>
          <span className="brand-mark mb-4" aria-hidden="true" />
          <CardTitle>Регистрация</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={submit}>
            <div className="space-y-2">
              <Label htmlFor="name">Имя</Label>
              <Input id="name" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" autoComplete="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Телефон</Label>
              <Input id="phone" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+7..." />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Пароль</Label>
              <Input
                id="password"
                autoComplete="new-password"
                minLength={8}
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
              />
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <Button className="w-full" disabled={loading} type="submit">
              {loading ? "Создаем..." : "Создать аккаунт"}
            </Button>
          </form>
          <div className="mt-5 text-center text-sm text-muted-foreground">
            Уже есть аккаунт?{" "}
            <Link className="font-semibold text-foreground hover:text-primary" href="/login">
              Войти
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
