import { Bot, Laptop, MonitorSmartphone, Router, Smartphone, type LucideIcon } from "lucide-react";

import { Card } from "@/components/ui/card";

const guides: Array<{ title: string; text: string; icon: LucideIcon }> = [
  { title: "iPhone", text: "Установите приложение, отсканируйте QR-код и включите VPN.", icon: Smartphone },
  { title: "Android", text: "Импортируйте QR-код или файл конфигурации в выбранное приложение.", icon: MonitorSmartphone },
  { title: "Windows", text: "Скачайте конфигурацию и импортируйте её в приложение клиента.", icon: Laptop },
  { title: "macOS", text: "Используйте QR-код или файл из раздела подключений.", icon: Laptop },
  { title: "Роутер", text: "Создайте подключение для роутера и скачайте файл настройки.", icon: Router },
  { title: "Telegram-бот", text: "Откройте бота для быстрой помощи и получения конфигов.", icon: Bot },
];

export default function HelpPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Помощь</h1>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {guides.map(({ title, text, icon: Icon }) => (
          <Card key={title} className="p-6">
            <Icon className="h-8 w-8 text-primary" />
            <h2 className="mt-5 text-xl font-semibold">{title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{text}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
