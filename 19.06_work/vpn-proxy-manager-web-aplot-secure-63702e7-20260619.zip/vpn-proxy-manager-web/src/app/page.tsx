import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";

import { ConnectionCard } from "@/components/app/connection-card";
import { CreateConnectionFlow } from "@/components/app/create-connection-flow";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getConnections, getCurrentUser, getSubscription } from "@/lib/api";

export default async function Home() {
  const [user, subscription, connections] = await Promise.all([
    getCurrentUser(),
    getSubscription(),
    getConnections(),
  ]);

  if (!user) {
    redirect("/login");
  }
  if (!subscription) {
    redirect("/profile");
  }

  const isSubscriptionActive = subscription.status === "Активна" || subscription.status === "Истекает";
  const accessLeft = getAccessLeft(subscription);

  return (
    <div className="space-y-5">
      <section className="flex flex-col justify-between gap-3 lg:flex-row lg:items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Здравствуйте, {user.name}</h1>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[1.4fr_1fr_1fr]">
        <Card className="brand-panel border-primary/30 bg-[linear-gradient(135deg,oklch(0.22_0.06_252_/_0.96),oklch(0.14_0.035_255_/_0.96))]">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <CardTitle>Ваша подписка</CardTitle>
              <Badge variant={isSubscriptionActive ? "success" : "danger"}>
                {isSubscriptionActive ? "активна" : "неактивна"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-sm text-muted-foreground">Осталось</p>
            <div className="mt-2 text-3xl font-bold">{accessLeft}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Активных подключений</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-3xl font-bold">{subscription.activeConnections}</div>
            <p className="mt-2 text-sm text-muted-foreground">из {subscription.maxConnections} устройств</p>
            <Button asChild className="mt-4" size="sm" variant="ghost">
              <Link href="/connections">
                Управление подключениями <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Быстрое подключение</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="mb-4 text-sm text-muted-foreground">Создайте конфигурацию для нового устройства.</p>
            <CreateConnectionFlow compact />
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader className="flex-row items-center justify-between py-4">
            <CardTitle>Последние подключения</CardTitle>
            <Button asChild size="sm" variant="ghost">
              <Link href="/connections">Смотреть все</Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-3 pt-0">
            {connections.slice(0, 3).map((connection) => (
              <ConnectionCard compact key={connection.id} connection={connection} />
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Нужна помощь?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {["Как подключить iPhone", "Как подключить Android", "Как подключить Windows", "Telegram-бот"].map((item) => (
              <Link key={item} href="/help" className="flex items-center justify-between text-sm text-muted-foreground hover:text-foreground">
                {item}
                <ArrowRight className="h-4 w-4" />
              </Link>
            ))}
          </CardContent>
        </Card>
      </section>

    </div>
  );
}

function getAccessLeft(subscription: { status: string; expiresAt: string }) {
  if (subscription.status === "Неактивна") {
    return "-";
  }

  const rawExpiresAt = subscription.expiresAt.trim().toLowerCase();
  if (!rawExpiresAt || rawExpiresAt === "без срока") {
    return "∞";
  }

  const expiresAt = new Date(subscription.expiresAt);
  if (Number.isNaN(expiresAt.getTime())) {
    return "∞";
  }

  const diffMs = expiresAt.getTime() - Date.now();
  if (diffMs <= 0) {
    return "-";
  }

  const totalHours = Math.ceil(diffMs / (1000 * 60 * 60));
  const days = Math.floor(totalHours / 24);
  const hours = totalHours % 24;

  if (days <= 0) {
    return `${hours} ч`;
  }

  return `${days} д ${hours} ч`;
}
