import { CreateConnectionFlow } from "@/components/app/create-connection-flow";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function NewConnectionPage() {
  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Создать конфигурацию</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Мастер создания</CardTitle>
        </CardHeader>
        <CardContent>
          <CreateConnectionFlow compact />
        </CardContent>
      </Card>
    </div>
  );
}
