import { ConnectionCard } from "@/components/app/connection-card";
import { CreateConnectionFlow } from "@/components/app/create-connection-flow";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getConnections, getCurrentUser } from "@/lib/api";
import { redirect } from "next/navigation";

export default async function ConnectionsPage() {
  const [user, connections] = await Promise.all([getCurrentUser(), getConnections()]);
  if (!user) {
    redirect("/login");
  }

  const usedConnections = connections.length;
  const totalConnections = user.quotaConfigs ?? 0;
  const usagePercent = totalConnections > 0 ? (usedConnections / totalConnections) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h1 className="text-3xl font-bold">Подключения</h1>
        </div>
        <CreateConnectionFlow />
      </div>

      <Card className="border-primary/25">
        <CardContent className="space-y-4 pt-6">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Использовано из общего пула</div>
              <div className="mt-1 text-2xl font-semibold">
                {usedConnections} из {totalConnections}
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              {totalConnections > 0 ? `${Math.max(0, totalConnections - usedConnections)} доступно` : "доступ не выдан"}
            </div>
          </div>
          <Progress value={usagePercent} className="h-3" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ваши устройства</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {connections.length ? (
            connections.map((connection) => <ConnectionCard key={connection.id} connection={connection} />)
          ) : (
            <div className="rounded-lg border border-dashed border-border p-6 text-sm text-muted-foreground">
              У вас пока нет подключений.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
