import { Download, ShieldCheck } from "lucide-react";
import { notFound, redirect } from "next/navigation";

import { ConnectionQr } from "@/components/app/connection-qr";
import { CopyConfigButton } from "@/components/app/copy-config-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getConnection, getCurrentUser } from "@/lib/api";

export default async function ConnectionDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }

  const connection = await getConnection(id);

  if (!connection) {
    notFound();
  }

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <Badge>{connection.protocol}</Badge>
        <h1 className="mt-3 text-3xl font-bold">{connection.deviceName}</h1>
      </div>
      <div className="grid gap-5 lg:grid-cols-[auto_1fr]">
        <Card className="p-6">
          <ConnectionQr value={connection.connectUrl} />
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Подключение активно
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Row label="Устройство" value={connection.deviceName} />
            <Row label="Протокол" value={connection.protocol} />
            <Row label="Статус" value={connection.status} />
            <Row label="Создано" value={connection.createdAt} />
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button asChild>
                <a href={connection.configUrl}>
                  <Download className="h-4 w-4" />
                  Скачать конфигурацию
                </a>
              </Button>
              <CopyConfigButton configUrl={connection.configUrl} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-border pb-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}
