# NetConnect Web Cabinet

MVP личного кабинета пользователя для выпуска и управления VPN-конфигурациями.

## Запуск

```bash
cd web
cp .env.example .env.local
npm install
npm run dev
```

Откройте `http://localhost:3000`.

Для проверки с реальным Python API:

```bash
cd ..
python -m uvicorn vpn_service.api:app --reload --port 8000
cd web
echo VPN_BACKEND_URL=http://127.0.0.1:8000>>.env.local
npm run dev
```

## Что внутри

- Next.js App Router, TypeScript, Tailwind CSS.
- shadcn/ui-compatible primitives в `src/components/ui`.
- Dark theme в стиле Telegram Premium, Linear и Vercel.
- Адаптивный layout с разделами: Главная, Подключения, Подписка, Помощь, Профиль.
- Встроенный local backend на Next.js route handlers.
- Cookie-сессии через `vpn_session`.
- Регистрация и вход по email/паролю; телефон хранится как будущий альтернативный идентификатор.
- В модели пользователя есть задел под 2FA (`twoFactorEnabled`, будущие методы `totp`/`email`/`sms`).
- Guarded 3x-ui v3 adapter: реальные мутации включаются только через `XUI_ENABLE_REAL_CLIENT_MUTATIONS=true`.

## Локальный backend

Если `VPN_BACKEND_URL` не задан, приложение использует встроенный backend.
Данные хранятся в gitignored-файле `.local-data/vpn-manager.json`.
Новая локальная база стартует без пользовательских VPN-конфигураций: аккаунты создаются через регистрацию, квоты выдает администратор.

Реализовано:

- регистрация пользователя по email/паролю с optional phone;
- вход по email или телефону;
- httpOnly cookie-сессия;
- logout с отзывом сессии;
- пользователи с ролями `admin` и `user`;
- статус пользователя `active`/`blocked`;
- квота `quotaConfigs` и счётчик `usedConfigs`;
- запрет создания конфигурации, если `usedConfigs >= quotaConfigs`;
- связь конфигурации с владельцем через `ownerId`;
- audit log для регистрации, сессий, создания/изменения пользователей, выпуска, отзыва и отказа по квоте;
- реальный 3x-ui v3 adapter для VLESS Reality при включенном `XUI_ENABLE_REAL_CLIENT_MUTATIONS=true`;
- безопасные read-only diagnostics/snapshot endpoints для проверки 3x-ui.

Кнопка продления подписки пока создает только пользовательский запрос через поддержку.

## Admin API

- `GET /api/admin/users`
- `POST /api/admin/users`
- `PATCH /api/admin/users/{id}`
- `GET /api/admin/audit`
- `GET /api/admin/xui/diagnostics`
- `POST /api/admin/xui/snapshot`
- `POST /api/admin/xui/test-client-plan`

Для локальной проверки можно использовать demo bearer-токен `Bearer demo:admin_01`.
В production задайте `VPN_ADMIN_API_TOKEN` и не используйте demo-токены как реальную авторизацию.

## Что подключить позже

- Двухфакторную проверку входа.
- Подтверждение email и телефона.
- Вход через Telegram Login Widget или magic link.
- Реальный backend для AmneziaWG 2.0.
- Платежи и автоматическое продление подписки.

Админка сайта, мониторинг, графики трафика и платежи намеренно не реализованы в MVP.

## API Contract

Python API уже предоставляет минимальные методы:

- `POST /auth/login`
- `GET /me`
- `GET /subscription`
- `GET /configs`
- `POST /configs`
- `GET /configs/{id}`
- `GET /configs/{id}/qr`
- `GET /configs/{id}/download`
- `POST /configs/{id}/revoke`
- `GET /servers`

Next.js routes используют совместимые пути `/api/...` и проксируют в backend через `VPN_BACKEND_URL`.
